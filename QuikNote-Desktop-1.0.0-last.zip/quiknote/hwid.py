# -*- coding: utf-8 -*-
import hashlib, platform, uuid, os, sys, subprocess
from typing import List

def _sha256(s: str) -> str:
    return hashlib.sha256(s.encode('utf-8', errors='ignore')).hexdigest()

def _safe(cmd: List[str]) -> str:
    try:
        return subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True, shell=False).strip()
    except Exception:
        return ""

def _machine_sig() -> str:
    return f"{platform.system()}|{platform.release()}|{platform.machine()}|{platform.node()}|{os.getenv('COMPUTERNAME','')}"

def current_hwid_hex() -> str:
    parts = []
    if platform.system().lower() == 'windows':
        reg = _safe(['reg','query',r'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography','/v','MachineGuid'])
        if reg:
            for ln in reg.splitlines():
                if 'MachineGuid' in ln:
                    parts.append(ln.split()[-1])
                    break
        cpu = _safe(['wmic','cpu','get','ProcessorId'])
        if cpu:
            vals = [v for v in cpu.splitlines() if v.strip() and v.strip().lower()!='processorid']
            if vals: parts.append(vals[0].strip())
        disk = _safe(['wmic','diskdrive','get','SerialNumber'])
        if disk:
            vals = [v for v in disk.splitlines() if v.strip() and v.strip().lower()!='serialnumber']
            if vals: parts.append(vals[0].strip())
    parts.append(f"{uuid.getnode():012x}")
    parts.append(_machine_sig())
    token = '|'.join([p for p in parts if p])
    salt  = f"py{sys.version_info.major}.{sys.version_info.minor}-{platform.platform()}-{os.name}"
    return _sha256(token+'|'+salt)

def get_hwid() -> str:
    return current_hwid_hex()

def get_hwid_legacy() -> str:
    return _sha256("legacy|" + f"{uuid.getnode():012x}")
