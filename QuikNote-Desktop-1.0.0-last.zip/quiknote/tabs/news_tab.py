# -*- coding: utf-8 -*-
from __future__ import annotations
import threading, re, html
from typing import Any, Dict, List, Optional

import requests
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QScrollArea, QFrame,
    QLabel, QPushButton, QSizePolicy, QMessageBox
)
from PySide6.QtCore import Qt, Signal, QEvent
from PySide6.QtGui import QPalette, QTextOption

# اگر کاربر URL نداد، از این استفاده می‌کنیم
CENTRAL_SITE_BASE = "https://quiknote.ir"
DEFAULT_POST_ID = 184

# -------------------- helpers --------------------

def _strip_html(s: Any) -> str:
    if s is None:
        return ""
    if isinstance(s, dict):
        s = s.get("rendered", "") or ""
    s = re.sub(r"<[^>]+>", "", str(s))
    s = html.unescape(s)
    return s.strip()

def _force_rtl_label(lbl: QLabel):
    lbl.setLayoutDirection(Qt.RightToLeft)
    lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    lbl.setStyleSheet("qproperty-alignment: AlignRight; text-align: right; background: transparent; border: none;")

# -------------------- UI widgets (مشابه ساپورت تب) --------------------

class MessageBox(QFrame):
    def __init__(self, text: str, meta: str, parent=None):
        super().__init__(parent)

        # کل کارت راست‌به‌چپ
        self.setLayoutDirection(Qt.RightToLeft)

        v = QVBoxLayout(self)
        v.setContentsMargins(12, 10, 12, 8)
        v.setSpacing(6)

        # متن
        self.lbl_text = QLabel()
        self.lbl_text.setTextFormat(Qt.RichText)
        self.lbl_text.setWordWrap(True)
        self.lbl_text.setAlignment(Qt.AlignRight | Qt.AlignTop)
        self.lbl_text.setLayoutDirection(Qt.RightToLeft)

        safe_txt = html.escape(text or "").replace("\n", "<br/>")
        self.lbl_text.setText(
            f"<p align='right' dir='rtl' style='margin:0; white-space:normal'>{safe_txt}</p>"
        )
        self.lbl_text.setStyleSheet("background: transparent; border: none;")

        # متا (تاریخ/نویسنده)
        self.lbl_meta = QLabel()
        self.lbl_meta.setTextFormat(Qt.RichText)
        self.lbl_meta.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.lbl_meta.setLayoutDirection(Qt.RightToLeft)
        safe_meta = html.escape(meta or "")
        self.lbl_meta.setText(f"<p align='right' dir='rtl' style='margin:0'>{safe_meta}</p>")
        self.lbl_meta.setStyleSheet("background: transparent; border: none; font-size:12px;")

        v.addWidget(self.lbl_text)
        v.addWidget(self.lbl_meta)

        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)

    def apply_theme(self, is_dark: bool):
        if is_dark:
            bg = "#2a2e33"; border = "#3a3f44"; text_color = "#ffffff"; meta_color = "rgba(255,255,255,0.65)"
        else:
            bg = "#f8f9fa"; border = "#d0d7de"; text_color = "#212529"; meta_color = "#495057"
        css = f"QFrame{{background:{bg}; border:1px solid {border}; border-radius:10px;}}"
        self.setStyleSheet(css)
        self.lbl_text.setStyleSheet(f"background: transparent; border: none; color:{text_color};")
        self.lbl_meta.setStyleSheet(f"background: transparent; border: none; color:{meta_color}; font-size:12px;")


class CardsPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setLayoutDirection(Qt.RightToLeft)
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(10, 10, 10, 10)
        self.lay.setSpacing(10)

    def apply_theme(self, is_dark: bool):
        if is_dark:
            bg = "#1f2328"; border = "#3a3f44"
        else:
            bg = "#ffffff"; border = "#d0d7de"
        self.setStyleSheet(f"QFrame{{background:{bg}; border:1px solid {border}; border-radius:10px;}}")


# -------------------- Main Tab --------------------

class NewsTab(QWidget):
    sigReloadUI     = Signal(list)   # لیست خبرها/کامنت‌ها
    sigShowError    = Signal(str)
    sigRefreshDone  = Signal()

    def __init__(self, state: dict, parent=None):
        super().__init__(parent)
        self.state = state or {}
        self._build_ui()

    # theme helpers
    def _is_dark_theme(self) -> bool:
        pal = self.palette()
        w = pal.color(QPalette.Window)
        return w.lightness() < 128

    def event(self, e):
        if e.type() == QEvent.PaletteChange:
            self._apply_theme()
        return super().event(e)

    def _build_ui(self):
        self.setLayoutDirection(Qt.RightToLeft)

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(12)

        self.title_lbl = QLabel('اخبار و اطلاعیه‌ها'); _force_rtl_label(self.title_lbl)
        self.title_lbl.setStyleSheet(self.title_lbl.styleSheet() + " font-weight:600;")
        root.addWidget(self.title_lbl)

        # پنل کارت‌ها + اسکرول
        self.panel = CardsPanel()
        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True); self.scroll.setFrameShape(QFrame.NoFrame)
        try:
            self.scroll.setLayoutDirection(Qt.RightToLeft)
            self.scroll.setAlignment(Qt.AlignRight | Qt.AlignTop)
        except Exception:
            pass

        self.container = QWidget(); self.container.setLayoutDirection(Qt.RightToLeft)
        self.list_layout = QVBoxLayout(self.container); self.list_layout.setContentsMargins(0,0,0,0); self.list_layout.setSpacing(10)
        try:
            self.list_layout.setAlignment(Qt.AlignTop | Qt.AlignRight)
        except Exception:
            pass
        self.list_layout.addStretch(1)

        self.scroll.setWidget(self.container)
        self.panel.lay.addWidget(self.scroll)
        root.addWidget(self.panel, 1)

        # نوار دکمه
        bar = QHBoxLayout(); bar.setContentsMargins(0,0,0,0); bar.setSpacing(6)
        self.btn_refresh = QPushButton('بروزرسانی')
        self.btn_refresh.clicked.connect(self._refresh)
        bar.addWidget(self.btn_refresh, 0, Qt.AlignRight)
        bar.addStretch(1)
        root.addLayout(bar)

        # سیگنال‌ها
        self.sigReloadUI.connect(self._populate)
        self.sigShowError.connect(lambda m: QMessageBox.critical(self, 'اخبار', m))
        self.sigRefreshDone.connect(self._restore_refresh_button)

        # استایل و لود اولیه
        self._apply_theme()
        self._refresh()

    def _apply_theme(self):
        is_dark = self._is_dark_theme()
        self.panel.apply_theme(is_dark)
        for i in range(self.list_layout.count() - 1):
            w = self.list_layout.itemAt(i).widget()
            if isinstance(w, MessageBox):
                w.apply_theme(is_dark)

    def _base_url(self) -> str:
        return (self.state.get('central_url') or CENTRAL_SITE_BASE).strip()

    def _post_id(self) -> int:
        # امکان override از state؛ پیش‌فرض 184
        try:
            return int(self.state.get('news_post_id') or DEFAULT_POST_ID)
        except Exception:
            return DEFAULT_POST_ID

    def _refresh(self):
        # UI: disable + فیدبک
        self.btn_refresh.setEnabled(False)
        self.btn_refresh.setText('در حال بروزرسانی…')
        self.title_lbl.setText('اخبار و اطلاعیه‌ها (در حال بروزرسانی...)')

        def work():
            try:
                base = self._base_url().rstrip("/")
                post_id = self._post_id()
                # فقط کامنت‌های post=184 (یا مقدار سفارشی‌شده در state)؛ جدیدترین اول
                url = f"{base}/wp-json/wp/v2/comments"
                params = {
                    "post": post_id,
                    "per_page": 100,
                    "orderby": "date",
                    "order": "desc",
                    "_fields": "id,date,content,author_name"
                }
                r = requests.get(url, params=params, timeout=15)
                r.raise_for_status()
                data = r.json()
                items: List[Dict[str, str]] = []
                for it in data or []:
                    content = it.get("content", {}).get("rendered", "") or ""
                    date = str(it.get("date", "") or "")
                    author = str(it.get("author_name", "") or "")
                    # متن و متا
                    from datetime import datetime

                    raw_date = str(it.get("date", "") or "")
                    author = str(it.get("author_name", "") or "")

                    # تبدیل ISO به تاریخ/ساعت محلی (در صورت امکان)
                    try:
                        dt = datetime.fromisoformat(raw_date.replace("Z", "+00:00"))
                        date_str = dt.strftime("%Y/%m/%d")
                        time_str = dt.strftime("%H:%M")
                        meta = f"در تاریخ {date_str} و ساعت {time_str} توسط {author}" if author else f"در تاریخ {date_str} و ساعت {time_str}"
                    except Exception:
                        meta = f"توسط {author} - {raw_date}" if author and raw_date else (author or raw_date)

                    items.append({
                        "text": _strip_html(content),
                        "meta": meta
                    })
                if not items:
                    items = [{"text": "اطلاعیه‌ای یافت نشد.", "meta": ""}]
                self.sigReloadUI.emit(items)
            except Exception as e:
                self.sigReloadUI.emit([{"text": f"خطا در دریافت اطلاعیه‌ها: {e}", "meta": ""}])
            finally:
                self.sigRefreshDone.emit()

        threading.Thread(target=work, daemon=True).start()

    def _restore_refresh_button(self):
        self.btn_refresh.setEnabled(True)
        self.btn_refresh.setText('بروزرسانی')
        self.title_lbl.setText('اخبار و اطلاعیه‌ها')

    def _populate(self, items: List[Dict[str, str]]):
        # پاک‌سازی
        while self.list_layout.count() > 0:
            it = self.list_layout.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)

        is_dark = self._is_dark_theme()

        # افزودن کارت‌ها
        for it in items:
            box = MessageBox(it.get("text",""), it.get("meta",""))
            box.apply_theme(is_dark)
            box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
            self.list_layout.addWidget(box)

        self.list_layout.addStretch(1)
        # اسکرول به بالا (جدیدترین‌ها بالا هستند)
        self.scroll.verticalScrollBar().setValue(0)
