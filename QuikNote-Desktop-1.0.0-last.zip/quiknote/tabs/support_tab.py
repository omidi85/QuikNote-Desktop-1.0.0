# -*- coding: utf-8 -*-
from __future__ import annotations
import threading, re, html
from typing import Any, Dict, List, Optional

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QScrollArea, QFrame,
    QLabel, QPushButton, QTextEdit, QSizePolicy, QMessageBox
)
from PySide6.QtCore import Qt, Signal, QEvent
from PySide6.QtGui import QPalette, QTextOption

# API پروژه
from ..api import CentralAPI

# سرور مرکزی (در صورت نبود در state همین استفاده می‌شود)
CENTRAL_SITE_BASE = "https://quiknote.ir"

# -------------------- helpers --------------------

def _strip_html(s: Any) -> str:
    if s is None:
        return ""
    if isinstance(s, dict):
        s = s.get("rendered", "") or ""
    s = re.sub(r"<[^>]+>", "", str(s))
    s = html.unescape(s)
    return s.strip()

def _force_rtl_label(lbl: QLabel):
    lbl.setLayoutDirection(Qt.RightToLeft)
    lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    lbl.setStyleSheet("qproperty-alignment: AlignRight; text-align: right; background: transparent; border: none;")

def _force_rtl_textedit(te: QTextEdit):
    te.setLayoutDirection(Qt.RightToLeft)
    te.setAlignment(Qt.AlignRight)
    opt: QTextOption = te.document().defaultTextOption()
    opt.setAlignment(Qt.AlignRight)
    te.document().setDefaultTextOption(opt)
    te.setStyleSheet("text-align: right;")

def _safe_get(d: Any, *keys, default=None):
    if isinstance(d, dict):
        for k in keys:
            if k in d:
                return d[k]
    return default

def _normalize_comments(raw: Any) -> List[Dict[str, Any]]:
    """
    هر شکلی از پاسخ را به لیست یکنواخت تبدیل می‌کند:
      [{"content": str, "date": str, "by_admin": bool, "code": str}]
    """
    items: List[Dict[str, Any]] = []
    if raw is None:
        data = {}
    elif isinstance(raw, list):
        data = {"__list": raw}
    elif isinstance(raw, dict):
        data = raw
    else:
        data = {}

    if "data" in data and isinstance(data["data"], (dict, list)):
        sub = data["data"]
        if isinstance(sub, list):
            data = {"__list": sub}
        elif isinstance(sub, dict):
            data = sub

    candidates = None
    for k in ("comments", "replies", "messages", "items", "__list"):
        if isinstance(data.get(k), list):
            candidates = data.get(k)
            break

    if candidates is None and isinstance(data.get("ticket"), dict):
        if isinstance(data["ticket"].get("comments"), list):
            candidates = data["ticket"]["comments"]

    if candidates is None and isinstance(data, dict) and any(k in data for k in ("content","message","text","body")):
        candidates = [data]

    if not candidates:
        return []

    for it in candidates:
        if not isinstance(it, dict):
            continue
        content = _safe_get(it, "content","message","text","body", default="")
        date    = _safe_get(it, "date","created_at","createdAt","time","created", default="")
        code    = _safe_get(it, "code","id","comment_id","commentId", default="")
        by_admin = bool(
            _safe_get(it,"by_admin","is_admin","admin", default=False) or
            (_safe_get(it,"author_role", default="") in ("administrator","admin","support")) or
            (_safe_get(it,"from", default="") in ("admin","support"))
        )
        if isinstance(content, dict):
            content = content.get("rendered","") or ""
        items.append({
            "content": _strip_html(content),
            "date": str(date or ""),
            "by_admin": by_admin,
            "code": str(code or ""),
        })
    return items


# -------------------- UI widgets --------------------

class MessageBox(QFrame):
    def __init__(self, text: str, meta: str, by_admin: bool, parent=None):
        super().__init__(parent)
        self.by_admin = by_admin

        # کل کارت راست‌به‌چپ
        self.setLayoutDirection(Qt.RightToLeft)

        v = QVBoxLayout(self)
        v.setContentsMargins(12, 10, 12, 8)
        v.setSpacing(6)

        # ---- متن پیام (RichText راست‌چین) ----
        self.lbl_text = QLabel()
        self.lbl_text.setTextFormat(Qt.RichText)
        self.lbl_text.setWordWrap(True)
        self.lbl_text.setAlignment(Qt.AlignRight | Qt.AlignTop)
        self.lbl_text.setLayoutDirection(Qt.RightToLeft)

        safe_txt = html.escape(text or "").replace("\n", "<br/>")
        # نکته مهم: از align="right" و dir="rtl" استفاده می‌کنیم (در رندرر HTMLِ Qt معتبر است)
        self.lbl_text.setText(
            f"<p align='right' dir='rtl' style='margin:0; white-space:normal'>{safe_txt}</p>"
        )
        # استایل‌شیـت برای رنگ و بدون border؛ 'text-align' در stylesheet لازم نیست
        self.lbl_text.setStyleSheet("background: transparent; border: none;")

        # ---- متای پیام (کُد/تاریخ) راست‌چین ----
        self.lbl_meta = QLabel()
        self.lbl_meta.setTextFormat(Qt.RichText)
        self.lbl_meta.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.lbl_meta.setLayoutDirection(Qt.RightToLeft)

        safe_meta = html.escape(meta or "")
        self.lbl_meta.setText(
            f"<p align='right' dir='rtl' style='margin:0'>{safe_meta}</p>"
        )
        self.lbl_meta.setStyleSheet("background: transparent; border: none; font-size:12px;")

        v.addWidget(self.lbl_text)
        v.addWidget(self.lbl_meta)

        # کارت تمام‌عرض
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)

    def apply_theme(self, is_dark: bool):
        if is_dark:
            bg = "#2a2e33"; border = "#3a3f44"; text_color = "#ffffff"; meta_color = "rgba(255,255,255,0.65)"
        else:
            bg = "#f8f9fa"; border = "#d0d7de"; text_color = "#212529"; meta_color = "#495057"

        css = f"QFrame{{background:{bg}; border:1px solid {border}; border-radius:10px;}}"
        if self.by_admin:
            css = css.replace("}", "; border-bottom:2px solid #28a745; }")
        self.setStyleSheet(css)

        # رنگ متن/متا
        self.lbl_text.setStyleSheet(
            f"background: transparent; border: none; color:{text_color};"
        )
        self.lbl_meta.setStyleSheet(
            f"background: transparent; border: none; color:{meta_color}; font-size:12px;"
        )


class TicketsPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setLayoutDirection(Qt.RightToLeft)
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(10, 10, 10, 10)
        self.lay.setSpacing(10)

    def apply_theme(self, is_dark: bool):
        if is_dark:
            bg = "#1f2328"; border = "#3a3f44"
        else:
            bg = "#ffffff"; border = "#d0d7de"
        self.setStyleSheet(f"QFrame{{background:{bg}; border:1px solid {border}; border-radius:10px;}}")


# -------------------- Main tab --------------------

class SupportTab(QWidget):
    # سیگنال‌ها برای اجرای امن روی ترد اصلی
    sigReloadUI     = Signal(list)   # لیست پیام‌ها برای UI
    sigClearInput   = Signal()       # پاک کردن باکس تایپ
    sigShowError    = Signal(str)    # نمایش خطا
    sigToast        = Signal(str)    # پیام موفقیت
    sigRefreshDone  = Signal()       # پایان بروزرسانی (فعال‌سازی مجدد دکمه)
    sigSendDone     = Signal()       # پایان ارسال (فعال‌سازی مجدد دکمه ارسال)
    sigRequestRefresh = Signal()     # درخواست بروزرسانی (از ترد کارگر به ترد اصلی)

    def __init__(self, state: dict, parent=None):
        super().__init__(parent)
        self.state = state or {}
        self._build_ui()

    # ----- theme helpers -----
    def _is_dark_theme(self) -> bool:
        pal = self.palette()
        w = pal.color(QPalette.Window)
        return w.lightness() < 128

    def event(self, e):
        if e.type() == QEvent.PaletteChange:
            self._apply_theme()
        return super().event(e)

    # ----- UI build -----
    def _build_ui(self):
        self.setLayoutDirection(Qt.RightToLeft)

        root = QHBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(12)

        # ستون چپ (لیست پیام‌ها + بروزرسانی)
        left = QWidget(); lw = QVBoxLayout(left); lw.setContentsMargins(0,0,0,0); lw.setSpacing(8)
        self.title_lbl = QLabel('تیکت‌های قبلی'); _force_rtl_label(self.title_lbl)
        self.title_lbl.setStyleSheet(self.title_lbl.styleSheet() + " font-weight:600;")
        lw.addWidget(self.title_lbl)

        self.tickets_panel = TicketsPanel()
        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True); self.scroll.setFrameShape(QFrame.NoFrame)
        try:
            # تضمین راست‌چین شدن محتوای داخل اسکرول
            self.scroll.setLayoutDirection(Qt.RightToLeft)
            self.scroll.setAlignment(Qt.AlignRight | Qt.AlignTop)
        except Exception:
            pass

        self.thread_container = QWidget(); self.thread_container.setLayoutDirection(Qt.RightToLeft)
        self.thread_layout = QVBoxLayout(self.thread_container); self.thread_layout.setContentsMargins(0,0,0,0); self.thread_layout.setSpacing(10)
        try:
            self.thread_layout.setAlignment(Qt.AlignTop | Qt.AlignRight)
        except Exception:
            pass
        self.thread_layout.addStretch(1)

        self.scroll.setWidget(self.thread_container)
        self.tickets_panel.lay.addWidget(self.scroll)
        lw.addWidget(self.tickets_panel, 1)

        bar = QHBoxLayout(); bar.setContentsMargins(0,0,0,0); bar.setSpacing(6)
        self.btn_refresh = QPushButton('بروزرسانی پیام‌ها')
        self.btn_refresh.clicked.connect(self._refresh)  # فقط از ترد اصلی صدا زده می‌شود
        bar.addWidget(self.btn_refresh, 0, Qt.AlignRight)
        bar.addStretch(1)
        lw.addLayout(bar)

        # ستون راست (ارسال)
        right = QWidget(); rp = QVBoxLayout(right); rp.setContentsMargins(0,0,0,0); rp.setSpacing(8)
        lbl = QLabel('پیام شما'); _force_rtl_label(lbl)
        self.inp_msg = QTextEdit(); self.inp_msg.setPlaceholderText('مشکل خود را به‌طور کامل شرح دهید...'); self.inp_msg.setMinimumHeight(80)
        _force_rtl_textedit(self.inp_msg)
        self.btn_send = QPushButton('ارسال'); self.btn_send.clicked.connect(self._post)

        rp.addWidget(lbl); rp.addWidget(self.inp_msg, 1); rp.addWidget(self.btn_send, 0, Qt.AlignRight)

        root.addWidget(left, 7); root.addWidget(right, 3)

        # سیگنال‌ها → اسلات‌های ایمنِ UI
        self.sigReloadUI.connect(self._populate_thread)
        self.sigClearInput.connect(self.inp_msg.clear)
        self.sigShowError.connect(lambda m: QMessageBox.critical(self, 'پشتیبانی', m))
        self.sigToast.connect(lambda m: QMessageBox.information(self, 'پشتیبانی', m))
        self.sigRefreshDone.connect(self._restore_refresh_button)
        self.sigSendDone.connect(self._restore_send_button)
        self.sigRequestRefresh.connect(self._refresh)  # فراخوانی _refresh روی ترد اصلی

        # استایل اولیه + اولین بارگیری
        self._apply_theme()
        self._refresh()

    def _apply_theme(self):
        is_dark = self._is_dark_theme()
        self.tickets_panel.apply_theme(is_dark)
        for i in range(self.thread_layout.count() - 1):
            w = self.thread_layout.itemAt(i).widget()
            if isinstance(w, MessageBox):
                w.apply_theme(is_dark)

    # ----- Central API -----
    def _api(self) -> CentralAPI:
        # اگر در state آدرس نبود، از ثابت استفاده کن
        base = (self.state.get('central_url') or CENTRAL_SITE_BASE).strip()
        email = (self.state.get('central_email') or '').strip()
        pwd   = (self.state.get('central_password') or '').strip()
        return CentralAPI(base, email, pwd)

    def _config_error(self) -> Optional[str]:
        # URL را هاردکد در نظر می‌گیریم؛ فقط ایمیل و رمز لازم است
        email = (self.state.get('central_email') or '').strip()
        pwd   = (self.state.get('central_password') or '').strip()
        if not email or not pwd:
            return "تنظیمات حساب مرکزی ناقص است. ایمیل و رمز عبور را در تب تنظیمات کامل کنید."
        return None

    # ----- actions -----
    def _refresh(self):
        err = self._config_error()

        # UI: disable + تغییر متن (ایمن چون روی ترد اصلی هستیم)
        self.btn_refresh.setEnabled(False)
        self.btn_refresh.setText('در حال بروزرسانی…')
        self.title_lbl.setText('تیکت‌های قبلی (در حال بروزرسانی...)')

        if err:
            # تنظیمات ناقص
            self.sigReloadUI.emit([{"content": err, "date": "", "by_admin": False, "code": ""}])
            self.sigRefreshDone.emit()
            return

        def work():
            try:
                res = self._api().support_get()
                if isinstance(res, dict) and "code" in res and "message" in res and "data" in res:
                    raise RuntimeError(str(res.get("message") or res.get("code")))
                comments = _normalize_comments(res)
                if not comments:
                    comments = [{"content": "هیچ پیامی یافت نشد.", "date": "", "by_admin": False, "code": ""}]
                self.sigReloadUI.emit(comments)
            except Exception as e:
                self.sigReloadUI.emit([{"content": f"خطا در دریافت پیام‌ها: {e}", "date": "", "by_admin": False, "code": ""}])
            finally:
                self.sigRefreshDone.emit()
        threading.Thread(target=work, daemon=True).start()

    def _restore_refresh_button(self):
        self.btn_refresh.setEnabled(True)
        self.btn_refresh.setText('بروزرسانی پیام‌ها')
        self.title_lbl.setText('تیکت‌های قبلی')

    def _populate_thread(self, comments: list):
        # پاکسازی همه آیتم‌ها
        while self.thread_layout.count() > 0:
            it = self.thread_layout.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)

        is_dark = self._is_dark_theme()

        # افزودن کارت‌ها (تمام‌عرض)
        for c in comments:
            text = _strip_html(c.get('content', ''))
            date = str(c.get('date') or '')
            code = str(c.get('code') or c.get('id') or '')
            meta = f"{code} - {date}" if code and date else (code or date)
            by_admin = bool(c.get('by_admin'))

            box = MessageBox(text, meta, by_admin)
            box.apply_theme(is_dark)
            box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)

            # مستقیماً داخل لایهٔ ستونی؛ بدون Row/Stretch
            self.thread_layout.addWidget(box)

        # یک stretch انتهایی برای فاصله
        self.thread_layout.addStretch(1)

        # اسکرول به آخرین پیام
        self.scroll.verticalScrollBar().setValue(self.scroll.verticalScrollBar().maximum())

    def _restore_send_button(self):
        self.btn_send.setEnabled(True)
        self.btn_send.setText('ارسال')

    def _post(self):
        text = (self.inp_msg.toPlainText() or '').strip()
        if not text:
            self.sigShowError.emit("لطفاً متن پیام را وارد کنید.")
            return

        cfg_err = self._config_error()
        if cfg_err:
            self.sigShowError.emit(cfg_err)
            return

        # ضد دابل‌کلیک + فیدبک
        self.btn_send.setEnabled(False)
        self.btn_send.setText('در حال ارسال…')

        def work():
            try:
                res = self._api().support_post(text)
                if isinstance(res, dict) and "code" in res and "message" in res and "data" in res:
                    raise RuntimeError(str(res.get("message") or res.get("code")))
                self.sigClearInput.emit()
                self.sigToast.emit("پیام با موفقیت ارسال شد.")
                # درخواست بروزرسانی لیست پیام‌ها در ترد اصلی
                self.sigRequestRefresh.emit()
            except Exception as e:
                self.sigShowError.emit(f"ارسال ناموفق: {e}")
            finally:
                # همیشه روی ترد اصلی دکمه را برگردان
                self.sigSendDone.emit()

        threading.Thread(target=work, daemon=True).start()
