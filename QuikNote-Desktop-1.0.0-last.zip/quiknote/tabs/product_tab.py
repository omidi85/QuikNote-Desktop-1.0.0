# -*- coding: utf-8 -*-
from __future__ import annotations

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QProgressBar, QMessageBox, QGroupBox
)
from PySide6.QtCore import Qt, Signal, Slot


class ProductTab(QWidget):
    # Signals
    sigLog = Signal(str)
    sigProgress = Signal(int)
    sigInfo = Signal(str, str)
    sigWarn = Signal(str, str)
    sigError = Signal(str, str)

    def __init__(self, state: dict, parent=None):
        super().__init__(parent)
        self.state = state or {}
        self._build_ui()

        # Connect signals
        self.sigLog.connect(self._append_log)
        self.sigProgress.connect(self._on_progress)
        self.sigInfo.connect(self._on_info)
        self.sigWarn.connect(self._on_warn)
        self.sigError.connect(self._on_error)

    # ------------------ UI ------------------
    def _build_ui(self):
        v = QVBoxLayout(self)
        v.setContentsMargins(20, 20, 20, 20)
        v.setSpacing(12)

        form = QFormLayout()
        self.inp_product_name = QLineEdit()
        self.inp_product_name.setPlaceholderText("مثلاً: نام محصول")
        form.addRow('نام محصول', self.inp_product_name)
        v.addLayout(form)

        row = QHBoxLayout()
        self.btn_send_product = QPushButton('ارسال محتوای محصول')
        self.btn_send_product.clicked.connect(self._send_product_content) # Placeholder for method
        row.addWidget(self.btn_send_product)
        v.addLayout(row)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        v.addWidget(self.progress)

        self.txt_product_content = QTextEdit()
        self.txt_product_content.setAcceptRichText(True)
        v.addWidget(self.txt_product_content, 3)

        log_box = QGroupBox('گزارش عملیات')
        log_lay = QVBoxLayout(log_box)
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        log_lay.addWidget(self.txt_log)
        v.addWidget(log_box, 1)

    # ------------------ UI Slots ------------------
    @Slot(str)
    def _append_log(self, s: str):
        self.txt_log.append(s)

    @Slot(int)
    def _on_progress(self, val: int):
        self.progress.setValue(max(0, min(100, val)))

    @Slot(str, str)
    def _on_info(self, title: str, body: str):
        QMessageBox.information(self, title, body)

    @Slot(str, str)
    def _on_warn(self, title: str, body: str):
        QMessageBox.warning(self, title, body)

    @Slot(str, str)
    def _on_error(self, title: str, body: str):
        QMessageBox.critical(self, title, body)

    # ------------------ Product Content Sending ------------------
    def _send_product_content(self):
        product_name = self.inp_product_name.text().strip()
        if not product_name:
            self.sigWarn.emit('خطا', 'نام محصول را وارد کنید.')
            return
        self.sigLog.emit(f'در حال ارسال محتوای محصول برای: {product_name}')
        self.sigProgress.emit(100)
        self.sigInfo.emit('موفق', 'محتوای محصول ارسال شد. (این یک نمونه است)')
        self.txt_product_content.setHtml(f'<h1>محتوای محصول برای {product_name}</h1><p>توضیحات محصول در اینجا قرار می‌گیرد.</p>')
