# quiknote/tabs/published_tab.py
# -*- coding: utf-8 -*-
from __future__ import annotations

import re
from typing import List, Optional, Any

from PySide6.QtCore import Qt, Slot
from PySide6.QtGui import QGuiApplication, QPalette
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QTextEdit, QMessageBox,
    QAbstractItemView, QHeaderView, QDialog, QDialogButtonBox, QLabel
)

# فقط توابع موجود پروژه شما؛ حذف دیتابیس فراخوانی نمی‌شود
from ..storage_sqlite import list_articles, get_article


# -------------------- Helpers --------------------
def _safe_int(x: Any) -> Optional[int]:
    try:
        return int(str(x).strip())
    except Exception:
        return None


def _extract_wp_id(row: dict) -> str:
    """
    تلاش چندمرحله‌ای برای بدست آوردن WP ID:
    1) از کلیدهای رایج در دیکشنری
    2) از داخل لینک wp_url با regex های متداول وردپرسی
    """
    # 1) کلیدهای رایج
    for key in ("wp_id", "wpid", "wpPostId", "wordpress_id", "wpID", "wp_post_id"):
        v = row.get(key)
        v_int = _safe_int(v)
        if v_int is not None:
            return str(v_int)

    # 2) از لینک
    url = (row.get("wp_url") or row.get("link") or row.get("url") or "").strip()
    if url:
        # ?p=123
        m = re.search(r"[?&]p=(\d+)", url)
        if m:
            return m.group(1)
        # /archives/123
        m = re.search(r"/archives/(\d+)", url)
        if m:
            return m.group(1)
        # /p/123/
        m = re.search(r"/p/(\d+)(?:/|$)", url)
        if m:
            return m.group(1)

    return ""


# -------------------- Main Class --------------------
class PublishedTab(QWidget):
    COL_ID = 0
    COL_TITLE = 1
    COL_STATUS = 2
    COL_WP_ID = 3
    COL_LINK = 4
    COL_DATE = 5

    HEADERS = ["ID", "عنوان", "وضعیت", "WP ID", "لینک", "تاریخ"]

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._all_rows_cache: List[dict] = []
        self._dlg_html: Optional[QDialog] = None

        self._build_ui()
        self._apply_table_theme()   # ← هم دارک و هم لایت
        self._reload()

    # ---------------- UI ----------------
    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(8)

        # نوار بالا: جستجو + بروزرسانی
        top = QHBoxLayout()
        self.txt_search = QLineEdit(self)
        self.txt_search.setPlaceholderText("جستجو بر اساس عنوان/وضعیت/لینک …")
        self.txt_search.textChanged.connect(self._apply_filter)

        self.btn_refresh = QPushButton("بروزرسانی", self)
        self.btn_refresh.clicked.connect(self._reload)

        top.addWidget(QLabel("جستجو:"))
        top.addWidget(self.txt_search, 1)
        top.addWidget(self.btn_refresh)
        root.addLayout(top)

        # جدول
        self.tbl = QTableWidget(0, len(self.HEADERS), self)
        self.tbl.setHorizontalHeaderLabels(self.HEADERS)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tbl.horizontalHeader().setHighlightSections(False)
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.doubleClicked.connect(self._view_html)
        root.addWidget(self.tbl, 1)

        # دکمه‌ها
        btns = QHBoxLayout()

        self.btn_view = QPushButton("نمایش HTML", self)
        self.btn_view.clicked.connect(self._view_html)

        self.btn_copy = QPushButton("کپی لینک WP", self)
        self.btn_copy.clicked.connect(self._copy_link)

        self.btn_del_sel = QPushButton("حذف انتخاب‌شده‌ها", self)
        self.btn_del_sel.clicked.connect(self._delete_selected)

        self.btn_del_all = QPushButton("حذف همه ردیف‌ها", self)
        self.btn_del_all.clicked.connect(self._delete_all_rows)

        btns.addWidget(self.btn_view)
        btns.addWidget(self.btn_copy)
        btns.addStretch(1)
        btns.addWidget(self.btn_del_sel)
        btns.addWidget(self.btn_del_all)
        root.addLayout(btns)

    def _apply_table_theme(self) -> None:
        """
        بر اساس پالت سیستم / تم جاری:
        - اگر دارک باشد → استایل تیره
        - اگر لایت باشد → استایل پیش‌فرض Qt
        """
        pal = self.palette()
        base = pal.color(QPalette.Base)
        # بررسی روشن/تاریک بودن
        if base.value() < 128:  # Dark mode
            self.tbl.setStyleSheet(
                """
                QTableWidget {
                    background-color: #121212;
                    color: #EDEDED;
                    gridline-color: #2A2A2A;
                    selection-background-color: #2D6CDF;
                    selection-color: #FFFFFF;
                }
                QHeaderView::section {
                    background-color: #2A2A2A;
                    color: #000000;
                    padding: 6px;
                    border: 1px solid #2A2A2A;
                    font-weight: 600;
                }
                QTableCornerButton::section {
                    background-color: #1E1E1E;
                    border: 1px solid #2A2A2A;
                }
                QTableWidget::item:hover {
                    background-color: #202020;
                }
                """
            )
        else:  # Light mode → بدون استایل اضافی
            self.tbl.setStyleSheet("")

    # -------------- Data load --------------
    @Slot()
    def _reload(self) -> None:
        try:
            items = list_articles() or []
        except Exception as e:
            QMessageBox.critical(self, "خطا در بارگذاری", f"خواندن داده‌ها با خطا مواجه شد:\n{e}")
            items = []

        self._all_rows_cache = []
        for d in items:
            row = {
                "id": _safe_int(d.get("id")),
                "title": d.get("title") or d.get("seed") or "",
                "status": d.get("status") or "",
                "wp_url": d.get("wp_url") or d.get("link") or d.get("url") or "",
                "date": d.get("date") or d.get("created_at") or d.get("updated_at") or "",
            }
            row["wp_id"] = _extract_wp_id({**d, **row})
            self._all_rows_cache.append(row)

        self._populate_table(self._all_rows_cache)
        if self.txt_search.text().strip():
            self._apply_filter()

    def _populate_table(self, rows: List[dict]) -> None:
        self.tbl.setRowCount(0)
        self.tbl.setSortingEnabled(False)
        for r, obj in enumerate(rows):
            self.tbl.insertRow(r)

            def _set(col: int, text: str, center=False):
                it = QTableWidgetItem(text)
                if center:
                    it.setTextAlignment(Qt.AlignCenter | Qt.AlignVCenter)
                it.setToolTip(text)
                self.tbl.setItem(r, col, it)

            _set(self.COL_ID, str(obj.get("id", "") or ""), center=True)
            _set(self.COL_TITLE, obj.get("title", "") or "")
            _set(self.COL_STATUS, obj.get("status", "") or "", center=True)
            _set(self.COL_WP_ID, str(obj.get("wp_id", "") or ""), center=True)
            _set(self.COL_LINK, obj.get("wp_url", "") or "")
            _set(self.COL_DATE, obj.get("date", "") or "", center=True)

        self.tbl.setSortingEnabled(True)
        self.tbl.horizontalHeader().setSortIndicatorShown(True)

    # -------------- Filtering --------------
    @Slot()
    def _apply_filter(self) -> None:
        q = self.txt_search.text().strip().lower()
        if not q:
            self._populate_table(self._all_rows_cache)
            return

        filt = []
        for obj in self._all_rows_cache:
            haystack = " ".join(
                [
                    str(obj.get("id", "") or ""),
                    obj.get("title", "") or "",
                    obj.get("status", "") or "",
                    str(obj.get("wp_id", "") or ""),
                    obj.get("wp_url", "") or "",
                    obj.get("date", "") or "",
                ]
            ).lower()
            if q in haystack:
                filt.append(obj)
        self._populate_table(filt)

    # -------------- Helpers --------------
    def _current_article_id(self) -> Optional[int]:
        sel = self.tbl.selectionModel().selectedRows(self.COL_ID) if self.tbl.selectionModel() else []
        if not sel:
            r = self.tbl.currentRow()
            if r < 0:
                return None
            it = self.tbl.item(r, self.COL_ID)
            return _safe_int(it.text()) if it else None
        it = self.tbl.item(sel[0].row(), self.COL_ID)
        return _safe_int(it.text()) if it else None

    # -------------- Actions --------------
    @Slot()
    def _view_html(self) -> None:
        aid = self._current_article_id()
        if not aid:
            QMessageBox.information(self, "اطلاع", "لطفاً یک ردیف را انتخاب کنید.")
            return
        try:
            art = get_article(aid) or {}
        except Exception as e:
            QMessageBox.critical(self, "خطا", f"خواندن مقاله با خطا مواجه شد:\n{e}")
            return

        dlg = QDialog(self)
        dlg.setWindowTitle(f"HTML — {art.get('title') or art.get('seed') or aid}")
        dlg.resize(900, 600)
        lay = QVBoxLayout(dlg)

        ed = QTextEdit(dlg)
        ed.setReadOnly(True)
        ed.setPlainText(art.get("html", "") or "")
        lay.addWidget(ed, 1)

        btns = QDialogButtonBox(QDialogButtonBox.Close, parent=dlg)
        btns.rejected.connect(dlg.close)
        lay.addWidget(btns)

        dlg.show()
        self._dlg_html = dlg

    @Slot()
    def _copy_link(self) -> None:
        aid = self._current_article_id()
        if not aid:
            QMessageBox.information(self, "اطلاع", "لطفاً یک ردیف را انتخاب کنید.")
            return

        r = self.tbl.currentRow()
        link = ""
        if r >= 0:
            it = self.tbl.item(r, self.COL_LINK)
            link = it.text().strip() if it else ""
        if not link:
            try:
                art = get_article(aid) or {}
                link = (art.get("wp_url") or art.get("link") or art.get("url") or "").strip()
            except Exception:
                link = ""

        if not link:
            QMessageBox.warning(self, "هشدار", "لینکی برای کپی یافت نشد.")
            return

        QGuiApplication.clipboard().setText(link)
        QMessageBox.information(self, "کپی شد", "لینک در کلیپ‌بورد قرار گرفت.")

    # -------- حذف فقط در جدول (بدون تغییر DB) --------
    @Slot()
    def _delete_selected(self) -> None:
        sel = self.tbl.selectionModel().selectedRows(self.COL_ID) if self.tbl.selectionModel() else []
        ids: List[int] = []
        for mi in sel:
            it = self.tbl.item(mi.row(), self.COL_ID)
            if it:
                v = _safe_int(it.text())
                if v is not None:
                    ids.append(v)
        ids = sorted(set(ids))
        if not ids:
            QMessageBox.information(self, "اطلاع", "هیچ ردیفی انتخاب نشده است.")
            return

        ok = QMessageBox.question(
            self,
            "تایید حذف",
            f"آیا از حذف {len(ids)} ردیف از جدول اطمینان دارید؟",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if ok != QMessageBox.Yes:
            return

        self._all_rows_cache = [o for o in self._all_rows_cache if o.get("id") not in ids]
        if self.txt_search.text().strip():
            self._apply_filter()
        else:
            self._populate_table(self._all_rows_cache)

        QMessageBox.information(self, "انجام شد", "ردیف‌های انتخاب‌شده از جدول حذف شدند.")

    @Slot()
    def _delete_all_rows(self) -> None:
        rc = self.tbl.rowCount()
        if rc == 0:
            QMessageBox.information(self, "اطلاع", "جدول خالی است.")
            return

        ok = QMessageBox.question(
            self,
            "تایید حذف همه",
            f"همهٔ {rc} ردیف از جدول حذف شوند؟",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if ok != QMessageBox.Yes:
            return

        self._all_rows_cache.clear()
        self.tbl.setRowCount(0)
        QMessageBox.information(self, "انجام شد", "همهٔ ردیف‌ها از جدول حذف شدند.")
