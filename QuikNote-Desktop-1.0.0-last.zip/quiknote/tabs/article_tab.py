# quiknote/tabs/article_tab.py
# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import json
import re
import threading
import collections
import urllib.request
import urllib.error
from typing import List, Set, Deque, Optional

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTextEdit, QPushButton,
    QComboBox, QGroupBox, QFrame, QGraphicsOpacityEffect, QMessageBox
)
from PySide6.QtCore import (
    Qt, Signal, Slot, QPropertyAnimation, QEasingCurve, QTimer,
    QEvent, Property, QPoint
)
from PySide6.QtGui import QPainter, QColor, QBrush, QPen

# ====== سرویس‌ها ======
from ..gemini import generate_article
from ..wp_client import UserWP
from ..credits import consume as credits_consume, sync_from_server as credits_sync

# ====== ذخیره‌سازی مقالات در SQLite ======
from ..storage_sqlite import add_article, update_article_status


# ===================== Loaderِ پرومپت‌ها (JSON خارجی) =====================
# ===================== Loaderِ پرومپت‌ها (JSON خارجی) =====================
class PromptNotFoundError(LookupError):
    """وقتی کلید پرامپت در JSON پیدا نشود یا مقدارش خالی باشد."""
    pass

class PromptLoader:
    """
    پرامپت‌ها از فایل JSON:
      quiknote/prompts/prompts.json

    ساختار:
    {
      "blog": { "<goal_key>": "<prompt text>", ... },
      "megapost": "<prompt text>",
      "product": "<prompt text>"
    }
    """
    _cache: dict | None = None

    @classmethod
    def _prompts_path(cls) -> str:
        here = os.path.dirname(os.path.abspath(__file__))
        return os.path.normpath(os.path.join(here, "..", "prompts", "prompts.json"))

    @classmethod
    def reload(cls) -> None:
        """خالی‌کردن کش؛ بار بعدی از دیسک می‌خواند."""
        cls._cache = None

    @classmethod
    def _load_json(cls, *, strict: bool) -> dict:
        if cls._cache is not None:
            return cls._cache
        p = cls._prompts_path()
        try:
            with open(p, "r", encoding="utf-8") as f:
                cls._cache = json.load(f) or {}
        except Exception as e:
            if strict:
                raise FileNotFoundError(f"prompts.json پیدا نشد/قابل خواندن نیست: {p}\n{e}")
            cls._cache = {}
        return cls._cache

    @classmethod
    def get_prompt(cls, kind: str, goal_key: str | None, *, strict: bool = False) -> str:
        """
        strict=True: اگر کلید/مقدار نبود، استثناء می‌اندازد (بدون fallback).
        """
        base_constraints = (
            "خروجی باید فقط HTML معتبر باشد و هیچ متن غیر HTML تولید نشود. "
            "کل محتوا داخل <article> باشد؛ بدون <style> و بدون استایل inline. "
            "هدینگ‌های H2/H3 منظم، پاراگراف‌بندی خوانا، و ساختار استاندارد سئو."
        )

        data = cls._load_json(strict=strict)

        if kind == "blog":
            if not goal_key:
                if strict:
                    raise ValueError("goal_key برای 'blog' خالی است؛ کلیدِ هدف مشخص نشده.")
                # در حالت غیرسخت‌گیر می‌توانستیم fallback کنیم
                goal_key = ""

            blog_map = data.get("blog")
            if not isinstance(blog_map, dict):
                if strict:
                    raise PromptNotFoundError("بخش 'blog' در prompts.json پیدا نشد یا معتبر نیست.")
                blog_map = {}

            body = (blog_map.get(goal_key or "") or "").strip()
            if body:
                return f"{base_constraints}\n{body}".strip()

            if strict:
                raise PromptNotFoundError(f"کلید پرامپت برای بلاگ یافت نشد: blog['{goal_key}']")
            # (غیرسخت‌گیر: می‌توانست fallback کند)
            return f"{base_constraints}\nحداقل 1200 کلمه…"

        # kind = megapost / product
        body = (data.get(kind) or "").strip()
        if body:
            return f"{base_constraints}\n{body}".strip()

        if strict:
            raise PromptNotFoundError(f"کلید پرامپت '{kind}' در prompts.json یافت نشد یا خالی است.")
        # (غیرسخت‌گیر: می‌توانست fallback کند)
        return f"{base_constraints}\n..."


# ========================== Toast (مثل قبل) ==========================
class Toast(QFrame):
    def __init__(self, parent, text, kind="info", msec=3500):
        super().__init__(parent)
        self.setObjectName("toast")

        bg = {"info": "#16a34a", "warn": "#f59e0b", "error": "#dc2626"}.get((kind or "info").lower(), "#16a34a")

        self.setStyleSheet(f"""
            QFrame#toast {{ background: {bg}; color: #fff; border-radius: 12px; }}
            QLabel {{ color: #fff; font-weight: 500; }}
        """)
        lay = QHBoxLayout(self); lay.setContentsMargins(18, 12, 18, 12)
        self.lbl = QLabel(text); self.lbl.setWordWrap(True); lay.addWidget(self.lbl)

        self._fx = QGraphicsOpacityEffect(self); self.setGraphicsEffect(self._fx); self._fx.setOpacity(0.0)
        self._fade_in = QPropertyAnimation(self._fx, b"opacity", self); self._fade_in.setDuration(220)
        self._fade_in.setStartValue(0.0); self._fade_in.setEndValue(1.0)

        self._timer = QTimer(self); self._timer.setSingleShot(True); self._timer.timeout.connect(self._fade_out)
        self._timer.start(max(1500, int(msec)))

    def showEvent(self, e):
        super().showEvent(e)
        host = self.window() or self.parent()
        if host:
            self.adjustSize()
            x = (host.width() - self.width()) // 2
            y = (host.height() - self.height()) // 2
            self.move(max(8, x), max(8, y))
        self._fade_in.start()

    def _fade_out(self):
        fade_out = QPropertyAnimation(self._fx, b"opacity", self)
        fade_out.setDuration(300)
        fade_out.setStartValue(self._fx.opacity()); fade_out.setEndValue(0.0)
        fade_out.finished.connect(self.deleteLater); fade_out.start()


def show_toast(widget, text, kind="info", msec=3500):
    t = Toast(widget.window() or widget, text, kind=kind, msec=msec)
    t.raise_(); t.show()


def humanize_error(msg: str) -> str:
    s = (msg or "").strip()
    if "HTTP 403" in s or "Forbidden" in s or "<!DOCTYPE html" in s:
        return "عدم دسترسی به سرور هوش مصنوعی (HTTP 403). لطفاً کلید/دسترسی را بررسی کنید."
    if s.startswith("❌ تعداد تلاش‌ها تمام شد"):
        return "اتصال برقرار نشد: تعداد تلاش‌ها تمام شد. لطفاً کلید/دسترسی را بررسی کنید."
    return s if len(s) <= 300 else s[:300] + "…"


# ====================== Loader Overlay (بدون تغییر) ======================
class FileWidget(QWidget):
    def __init__(self, parent=None, delay=0):
        super().__init__(parent)
        self.setFixedSize(40, 50)
        self.delay = delay
        self.opacity_effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.opacity_effect)
        self._scale_factor = 0.0

    def getScaleFactor(self):
        return self._scale_factor

    def setScaleFactor(self, factor):
        self._scale_factor = factor; self.update()

    scale_factor = Property(float, getScaleFactor, setScaleFactor)

    def paintEvent(self, event):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        t = p.transform()
        t.translate(self.width() / 2, self.height() / 2)
        t.scale(max(0.001, self._scale_factor), max(0.001, self._scale_factor))
        t.translate(-self.width() / 2, -self.height() / 2)
        p.setTransform(t)
        p.setBrush(QBrush(QColor("#007bff"))); p.setPen(QPen(Qt.NoPen))
        p.drawRoundedRect(0, 0, 40, 50, 4, 4)
        p.setBrush(QBrush(Qt.white))
        p.drawRoundedRect(6, 6, 28, 4, 2, 2)
        p.drawRoundedRect(6, 13, 18, 4, 2, 2)


class LoaderOverlay(QWidget):
    OVERLAY_HEIGHT = 150
    def __init__(self, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, False)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAutoFillBackground(False)
        self._anims_pos = []; self._anims_op = []; self._anims_sc = []; self._anims_started = False
        self.files = []
        for i in range(6):
            fw = FileWidget(self, delay=i * 600); fw.move(-50, 0); self.files.append(fw)
        self.hide(); self.update_geometry()

    def update_geometry(self):
        win = self.parentWidget()
        if not win: return
        h = self.OVERLAY_HEIGHT
        self.setGeometry(0, max(0, (win.height() - h) // 2), max(1, win.width()), h)
        for fw in self.files:
            fw.move(fw.x(), (h - fw.height()) // 2)

    def _start_anim_for(self, fw: FileWidget):
        w = max(1, self.width()); y = fw.y()

        anim_pos = QPropertyAnimation(fw, b"pos", self)
        anim_pos.setDuration(5000)
        anim_pos.setStartValue(QPoint(-50, y))
        anim_pos.setKeyValueAt(0.4, QPoint(w // 2 - fw.width() // 2 - 20, y))
        anim_pos.setKeyValueAt(0.5, QPoint(w // 2 - fw.width() // 2, y))
        anim_pos.setKeyValueAt(0.6, QPoint(w // 2 - fw.width() // 2 + 20, y))
        anim_pos.setEndValue(QPoint(w, y)); anim_pos.setLoopCount(-1); anim_pos.setEasingCurve(QEasingCurve.InOutQuad)
        self._anims_pos.append(anim_pos)

        anim_op = QPropertyAnimation(fw.opacity_effect, b"opacity", self)
        anim_op.setDuration(5000); anim_op.setStartValue(0.0)
        anim_op.setKeyValueAt(0.2, 1.0); anim_op.setKeyValueAt(0.8, 1.0)
        anim_op.setEndValue(0.0); anim_op.setLoopCount(-1); self._anims_op.append(anim_op)

        anim_sc = QPropertyAnimation(fw, b"scale_factor", self)
        anim_sc.setDuration(5000); anim_sc.setStartValue(0.001)
        anim_sc.setKeyValueAt(0.5, 1.2); anim_sc.setEndValue(0.001)
        anim_sc.setLoopCount(-1); self._anims_sc.append(anim_sc)

        anim_pos.start(); anim_op.start(); anim_sc.start()

    def _ensure_anims_started(self):
        if self._anims_started: return
        self._anims_started = True
        for fw in self.files:
            QTimer.singleShot(fw.delay, lambda f=fw: self._start_anim_for(f))

    def show_overlay(self, on: bool):
        if on:
            self.update_geometry(); self.raise_(); self.show(); self._ensure_anims_started()
        else:
            self.hide()

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing, True)
        p.fillRect(self.rect(), QColor(0, 0, 0, 120))


# ============================ تب تولید مقاله ============================
class ArticleTab(QWidget):
    sigLog = Signal(str)
    sigInfo = Signal(str, str)
    sigWarn = Signal(str, str)
    sigError = Signal(str, str)
    sigCreditsChanged = Signal(int)
    sigArticleReady = Signal(dict)
    sigRemoveSeed = Signal(str)
    sigBusy = Signal(bool)
    sigToast = Signal(str, str)  # text, kind

    def __init__(self, state: dict, parent=None):
        super().__init__(parent)
        self.state = state or {}
        self._queue: Deque[str] = collections.deque()
        self._queue_lock = threading.Lock()
        self._produced: Set[str] = set()
        self._publishing = False
        self._current_record_id: str | None = None
        self._test_thread: Optional[threading.Thread] = None

        self._build_ui()

        self._overlay: LoaderOverlay | None = None
        self.sigBusy.connect(self._toggle_overlay_safe)

        self.sigLog.connect(self._append_log)
        self.sigRemoveSeed.connect(self._remove_seed_line)

        # پیام‌ها → Toast
        self.sigWarn.connect(lambda t, x: self.sigToast.emit(x, "warn"))
        self.sigError.connect(lambda t, x: self.sigToast.emit(x, "error"))
        self.sigInfo.connect(lambda t, x: self.sigToast.emit(x, "info"))
        self.sigToast.connect(self._on_toast)

    # ---------- UI ----------
    def _build_ui(self):
        from PySide6.QtWidgets import (
            QVBoxLayout, QHBoxLayout, QGroupBox, QTextEdit, QLabel,
            QPushButton, QFrame, QComboBox
        )

        root = QVBoxLayout(self);
        root.setSpacing(10);
        root.setContentsMargins(8, 8, 8, 8)

        # ── ردیف بالایی: 50% عناوین / 50% پرامپت اختصاصی کاربر
        row_top = QHBoxLayout()

        # (چپ) عنوان/موضوع
        box_input = QGroupBox("عنوان/موضوع (هر خط = یک مورد)")
        vl_in = QVBoxLayout(box_input)
        self.txt_seeds = QTextEdit();
        self.txt_seeds.setMinimumHeight(150)
        self.txt_seeds.setPlaceholderText("مثال:\nعنوان ۱\nعنوان ۲\nعنوان ۳")
        vl_in.addWidget(self.txt_seeds)
        row_top.addWidget(box_input, 1)  # 50%

        # (راست) پرامپت اختصاصی کاربر
        box_userp = QGroupBox("پرامپت اختصاصی کاربر (با اولویت بالاتر)")
        vl_up = QVBoxLayout(box_userp)
        self.txt_user_prompt = QTextEdit();
        self.txt_user_prompt.setMinimumHeight(150)
        self.txt_user_prompt.setPlaceholderText(
            "هر دستور/الزامی که می‌خواهی به مدل بدهی را اینجا بنویس.\n"
            "مثلاً: لحن داستانی، جدول مقایسه، CTA مشخص، مثال واقعی، ...\n"
            "اگر با قوانین دیگر تضاد داشت، اولویت با همین بخش است."
        )
        vl_up.addWidget(self.txt_user_prompt)
        row_top.addWidget(box_userp, 1)  # 50%

        root.addLayout(row_top, 2)

        # ── تنظیمات
        box_opts = QGroupBox("تنظیمات")
        hl = QHBoxLayout(box_opts)

        # نوع محتوا
        hl.addWidget(QLabel("نوع محتوا:"))
        self.cbo_type = QComboBox()
        self.cbo_type.addItem("مقاله وبلاگ", userData="blog")
        self.cbo_type.addItem("مگاپست", userData="megapost")
        self.cbo_type.addItem("تولید محصول", userData="product")
        self.cbo_type.currentIndexChanged.connect(self._on_type_changed)
        hl.addWidget(self.cbo_type, 1)

        # هدف محتوا (labels دیده می‌شن؛ IDs در userData ذخیره می‌شن)
        hl.addWidget(QLabel("هدف محتوا:"))
        self.cbo_goal = QComboBox()
        self._GOAL_OPTIONS = [  # (id, label)
            ("tutorial", "دانشنامه آموزشی / آموزش گام‌به‌گام (Tutorial)"),
            ("branding", "برندینگ (Branding)"),
            ("sales_marketing", "فروش و بازاریابی (Sales & Marketing)"),
            ("listicle", "لیستیکال (Listicle)"),
            ("comparison", "مقایسه (Comparison)"),
            ("faq", "پرسش و پاسخ (Q&A / FAQ)"),
            ("review", "نقد و بررسی (Review)"),
            ("news", "اطلاع‌رسانی (Announcement / News)"),
            ("storytelling", "داستان‌سرایی (Storytelling)"),
            ("ugc", "کاربرمحور (User-Generated / Testimonials)"),
            ("awareness", "آگاهی از برند (Educational / Awareness)"),
        ]
        self.cbo_goal.clear()
        for _id, _label in self._GOAL_OPTIONS:
            self.cbo_goal.addItem(_label, userData=_id)
        hl.addWidget(self.cbo_goal, 1)

        root.addWidget(box_opts)

        # ── کنترل‌ها
        row = QHBoxLayout();
        row.addStretch(1)
        self.btn_run = QPushButton("شروع تولید")
        self.btn_run.clicked.connect(self._start_or_resume)
        row.addWidget(self.btn_run)

        self.btn_test = QPushButton("تست سرور هوش مصنوعی")
        self.btn_test.setToolTip("پینگ سبک به API (بدون تولید محتوا و بدون Retry)")
        self.btn_test.clicked.connect(self._on_test_gemini)
        row.addWidget(self.btn_test)
        root.addLayout(row)

        # ── خط جداکننده + لاگ
        line = QFrame();
        line.setFrameShape(QFrame.HLine);
        line.setFrameShadow(QFrame.Sunken);
        root.addWidget(line)
        box_log = QGroupBox("گزارش")
        vl_log = QVBoxLayout(box_log)
        self.txt_log = QTextEdit();
        self.txt_log.setReadOnly(True);
        self.txt_log.setMinimumHeight(160)
        vl_log.addWidget(self.txt_log);
        root.addWidget(box_log, 2)

        self._on_type_changed()

    # ---------- helpers ----------
    def _on_toast(self, text: str, kind: str="info"):
        show_toast(self, humanize_error(text), kind)

    def _ensure_overlay(self):
        win = self.window() or self
        if self._overlay is None or self._overlay.parent() is not win:
            self._overlay = LoaderOverlay(win)
            win.installEventFilter(self)
        self._overlay.update_geometry()

    def eventFilter(self, obj, ev):
        if self._overlay and ev.type() in (QEvent.Resize, QEvent.Move):
            self._overlay.update_geometry()
        return super().eventFilter(obj, ev)

    def showEvent(self, e):
        super().showEvent(e)
        self._ensure_overlay()

    def _current_kind(self) -> str:
        idx = self.cbo_type.currentIndex()
        return self.cbo_type.itemData(idx) or "blog"

    def _on_type_changed(self):
        """
        کمبو هدف فقط برای 'blog' معنی دارد؛ برای 'megapost' و 'product' غیرفعال می‌شود.
        """
        try:
            kind = self._current_kind()
            if hasattr(self, "cbo_goal") and self.cbo_goal is not None:
                self.cbo_goal.setEnabled(kind == "blog")
        except Exception:
            pass

    def _current_goal_key(self) -> str:
        """
        کلید (ID) هدف محتوا را از کمبو می‌خواند؛ اگر چیزی انتخاب نشده باشد،
        روی هدف پیش‌فرض می‌افتیم.
        """
        DEFAULT_GOAL_KEY = "tutorial"  # خواستی تغییرش بده
        try:
            if self._current_kind() != "blog":
                return ""
            i = self.cbo_goal.currentIndex()
            key = (self.cbo_goal.itemData(i) or "").strip()
            return key or DEFAULT_GOAL_KEY
        except Exception:
            return DEFAULT_GOAL_KEY


    # ---------- API از تب عناوین ----------
    def add_to_queue(self, record_id: str, payloads: list[dict], delay_sec: int = -1):
        # سازگاری: شناسه رکورد فعال
        if record_id:
            self._current_record_id = record_id

        # مپ داخلیِ seed → keyword
        if not hasattr(self, "_seed_keywords") or not isinstance(getattr(self, "_seed_keywords"), dict):
            self._seed_keywords = {}

        seeds_new = []
        for p in (payloads or []):
            s = (p.get("seed") or "").strip()
            if not s:
                continue
            seeds_new.append(s)
            kw = (p.get("keyword") or p.get("focus_keyword") or p.get("kw") or "").strip()
            if kw:
                self._seed_keywords[s] = kw  # ← اینجا کلیدواژهٔ صحیح ذخیره می‌شود

        self._append_to_box_and_queue(seeds_new)

    def enqueue_from_titles(self, record_id: str, payloads: list[dict], delay_sec: int = -1):
        self.add_to_queue(record_id, payloads, delay_sec)

    def _start_article_generation(self, seed: str):
        s = (seed or "").strip()
        if s:
            self._append_to_box_and_queue([s])
        self._start_or_resume()

    # ---------- صف ----------
    def _append_to_box_and_queue(self, seeds: List[str]):
        if not seeds:
            return
        existing_lines = [ln.strip() for ln in self.txt_seeds.toPlainText().splitlines() if ln.strip()]
        existing_set = set(existing_lines)
        for s in seeds:
            if s and s not in existing_set:
                existing_lines.append(s); existing_set.add(s)
        self.txt_seeds.setPlainText("\n".join(existing_lines))
        self._rebuild_queue_from_text()

    def _rebuild_queue_from_text(self):
        lines = [ln.strip() for ln in self.txt_seeds.toPlainText().splitlines() if ln.strip()]
        uniq, seen = [], set()
        for s in lines:
            if s and s not in seen:
                uniq.append(s); seen.add(s)
        self._queue = collections.deque(uniq)

    # ---------- اجرا ----------

    def _build_prompt(self, kind: str, seed: str, goal_key: str) -> str:
        """
        پرامپت تولید مقاله برای Gemini با درنظرگرفتن:
        - هدف محتوا براساس ID انتخابی (labels در UI، ID پنهان)
        - پرامپت اختصاصی کاربر (با اولویت بالاتر)
        - الزامات سئو (عنوان/متا/اینترُ/بدنه/HTML)
        خروجی: JSON با فیلدهای title/keyword/alt_keywords/meta_description/html
        """
        # متن‌های هاردکد برای هر هدف (ID → متن)
        GOAL_PROMPTS = {
            "tutorial": (
                "مقالهٔ آموزشی گام‌به‌گام بنویس. ساختار: مقدمه کوتاه، پیش‌نیازها، فهرست مراحل با H2/H3، "
                "کد/مثال در صورت لزوم، خطاهای متداول، نکات تکمیلی، جمع‌بندی و چند سؤال متداول. "
                "متن روان و عملی؛ از جملات امری و لیست‌های مرحله‌ای استفاده کن."
            ),
            "branding": (
                "مقاله‌ای اعتبارساز برای برند تولید کن. لحن حرفه‌ای اما خودمانی؛ روایت داستانی کوتاه از مسئله تا راه‌حل؛ "
                "ارزش‌های کلیدی برند، تمایزها، لحن ثابت برند، Social Proof، و دعوت به تعامل. از کلیشه‌ها بپرهیز."
            ),
            "sales_marketing": (
                "مقاله‌ای متقاعدکننده با چارچوب‌های AIDA/PAS. درد مخاطب، راه‌حل، مزایا، شواهد، مقایسه کوتاه با جایگزین‌ها، "
                "CTA پررنگ. مانع‌های ذهنی را شناسایی و پاسخ بده. از جملات کوتاه، بولت‌ها و مثال واقعی استفاده کن."
            ),
            "listicle": (
                "یک لیستیکال ساختاریافته بنویس. عنوان‌های H2 شماره‌دار، برای هر مورد: توضیح کوتاه، مزایا/معایب، "
                "نکتهٔ کاربردی، درصورت امکان مثال کوتاه. جمع‌بندی و توصیه عملی در انتها."
            ),
            "comparison": (
                "مقالهٔ مقایسه‌ای بی‌طرفانه: معیارها را ابتدا تعریف کن (H2). سپس برای هر گزینه جدول/بولت از مزایا/معایب، "
                "موارد استفاده مناسب، و نتیجهٔ جمع‌بندی. در پایان پیشنهاد سناریومحور ارائه بده."
            ),
            "faq": (
                "یک مقاله به‌فرمت Q&A/FAQ تهیه کن. پرسش‌های پرتکرار را فهرست و برای هر کدام پاسخ شفاف، مختصر و عملی بده. "
                "از مثال‌ها و ارجاع داخلی به بخش‌های مرتبط استفاده کن."
            ),
            "review": (
                "نقد و بررسی عمیق با معیارهای شفاف: طراحی/کیفیت، کارایی، پشتیبانی، قیمت/ارزش، معایب احتمالی، "
                "جمع‌بندی برای چه کسانی مناسب است. تا حد امکان جزئیات عملی و مثال واقعی بده."
            ),
            "news": (
                "خبر/اطلاعیه حرفه‌ای بنویس: خلاصهٔ خبری در ابتدای مقاله، جزئیات کلیدی (چه/کی/کجا/چرا/چطور)، "
                "نقل‌قول کوتاه در صورت لزوم، و بخش «برای شروع/اطلاعات بیشتر» در انتها."
            ),
            "storytelling": (
                "روایت مسئله تا راه‌حل با ساختار داستانی: قهرمان/چالش/نقطهٔ عطف/راه‌حل/نتیجه. "
                "لحن انسانی، جزئیات حسی به‌اندازه، و جمع‌بندی الهام‌بخش همراه با CTA ملایم."
            ),
            "ugc": (
                "مقالهٔ مبتنی بر تجربه کاربران: نقل‌قول‌های برجسته، چالش‌ها و نتایج، الگوهای مشترک، و نکات عملی. "
                "از داده‌های واقعی/فرضی اعتباری استفاده کن؛ حریم خصوصی را رعایت کن."
            ),
            "awareness": (
                "مقالهٔ آموزشیِ آگاهی‌بخش: تعریف مسئله، چارچوب مفهومی، مثال‌های روشن، اشتباهات رایج، و چک‌لیست کوتاه عملی. "
                "لحن بی‌طرف و روشن؛ از اصطلاحات مبهم دوری کن."
            ),
            # نوع‌های دیگر
            "_megapost": (
                "یک مگاپست جامع و عمیق تولید کن. حداقل 5000 کلمه. ابتدا یک فهرست مطالب (table of contents) با لینک داخلی "
                "به سرفصل‌ها ارائه کن. بدنه را با H2/H3/H4 ساختار بده؛ برای هر زیربخش مثال عملی، نکتهٔ اجرایی، و در صورت نیاز "
                "جدول/blockquote اضافه کن. جمع‌بندی نهایی با برنامهٔ اقدام مرحله‌ای. از تکرار پرهیز کن و پیوستگی را حفظ کن."
            ),
            "_product": (
                "صفحهٔ محصول کامل بنویس: خلاصهٔ ارزش پیشنهادی، ویژگی‌های کلیدی به‌صورت بولت، مزایا/معایب، سناریوهای کاربرد، "
                "مقایسه کوتاه با گزینه‌های رایج (در صورت لزوم)، 3-5 پرسش متداول، و CTA واضح. لحن فروش‌محور اما شفاف باشد."
            ),
        }

        # نوع محتوا
        kind = (kind or "").strip().lower()
        # متن هدف
        if kind == "megapost":
            goal_text = GOAL_PROMPTS["_megapost"]
        elif kind == "product":
            goal_text = GOAL_PROMPTS["_product"]
        else:
            DEFAULT_GOAL_KEY = "tutorial"  # ← اگر کاربر چیزی انتخاب نکرده باشد
            key = (goal_key or "").strip().lower() or DEFAULT_GOAL_KEY
            goal_text = GOAL_PROMPTS.get(key, GOAL_PROMPTS[DEFAULT_GOAL_KEY])

        # پرامپت اختصاصی کاربر (با اولویت بالاتر)
        try:
            user_overrides = (self.txt_user_prompt.toPlainText() or "").strip()
        except Exception:
            user_overrides = ""

        # بدنهٔ اصلی پرامپت + الزامات سئو و Long-Tail
        style = "informative, practical, friendly"
        audience = "عموم کاربران وب فارسی"
        lang = "Persian (Farsi)"

        prompt = (
            "You are an expert SEO content writer for {lang} readers.\n"
            "\n"
            "Task:\n"
            f'- Given this working title (topic/angle): \"{seed}\"\n'
            "- Propose 3 semantically distinct, long-tail SEO keyword candidates (3–6 words each)\n"
            "  that real users search on Google, and that CLEARLY match the given title/topic.\n"
            "- Each candidate must:\n"
            "  • be a natural long-tail query (avoid single-word or too-broad head terms)\n"
            "  • include at least one core concept from the seed/title\n"
            "  • be free of quotes/emojis/hashtags\n"
            "- Choose the best candidate as the primary keyword.\n"
            "- Then write the article optimized for that primary keyword (not just for the title).\n"
            "\n"
            "Strict SEO placement requirements (MUST):\n"
            "1) SEO title must start with the primary keyword OR include it within the first 60 characters.\n"
            "2) Meta description must naturally include the primary keyword exactly once.\n"
            "3) The first paragraph must include the primary keyword within the first 20 words.\n"
            "4) In the body, use the primary keyword verbatim at least 3 times (plus natural synonyms if helpful).\n"
            "\n"
            "Article requirements:\n"
            "- Write the article in clean HTML inside a single <article>...</article> block.\n"
            "- Use <h2> for main sections and <h3> for subsections; use <p> for paragraphs.\n"
            "- Avoid inline styles; do not include <html>, <head>, or <body> tags.\n"
            "- Include a concise introduction and a closing takeaway.\n"
            "\n"
            "Goal-specific guidance:\n"
            f"{goal_text}\n"
        ).replace("{lang}", lang)

        # اگر هدف «داستان‌سرایی» است، قلاب روایت را هم اضافه کن
        if (goal_key or "").lower() == "storytelling":
            prompt += (
                "\nNarrative constraints (enforce):\n"
                "- Open with a 2–4 sentence scene that sets the stakes.\n"
                "- Introduce a protagonist (the reader or a persona) facing a clear obstacle.\n"
                "- Show a turning point and resolution; end with a soft CTA.\n"
                "- Keep H2/H3 structure, but write paragraphs like a story (sensory details in moderation).\n"
            )

        # پرامپت اختصاصی کاربر با اولویت بالاتر
        if user_overrides:
            prompt += (
                "\nUser override instructions (HIGHEST PRIORITY — if any conflict, follow these):\n"
                f"{user_overrides}\n"
            )

        # فرمت تحویل
        prompt += (
            "\nDelivery format:\n"
            "- Return ONLY a single JSON object (no extra text, no markdown fences) with exactly these fields:\n"
            '  • "title" (string)\n'
            '  • "keyword" (string: the chosen primary long-tail keyword, 3–6 words)\n'
            '  • "alt_keywords" (array of 3 strings: the proposed candidates)\n'
            '  • "meta_description" (string, 140–160 chars, naturally includes the primary keyword once)\n'
            '  • "html" (string: the full article HTML inside one <article>...</article>)\n'
            "\n"
            f"Style: {style}\n"
            f"Audience: {audience}\n"
        )

        return prompt

    def _clean_html(self, html: str) -> str:
        s = (html or "").strip()
        s = re.sub(r"<!DOCTYPE[^>]*>", "", s, flags=re.I)
        s = re.sub(r"<\?xml[^>]*\?>", "", s, flags=re.I)
        s = re.sub(r"<meta[^>]*qrichtext[^>]*>", "", s, flags=re.I)
        s = re.sub(r"<style[^>]*>.*?</style>", "", s, flags=re.S | re.I)
        m = re.search(r"<body[^>]*>(.*?)</body>", s, flags=re.S | re.I)
        if m: s = m.group(1)
        s = re.sub(r'\sstyle="[^"]*"', "", s, flags=re.I)
        s = re.sub(r"</?(html|head)\b[^>]*>", "", s, flags=re.I)
        if not re.search(r"<\s*article\b", s, flags=re.I):
            s = f"<article>{s}</article>"
        return s.strip()

    def _start_or_resume(self):
        """
        اجرای تولید + ذخیره در DB + ایجاد Post/Product + ست‌کردن سئو
        حالت محصول: Connector(HMAC) یا WooCommerce REST یا Basic Auth روی /qn/v1/product
        """
        import re, html, json, base64, urllib.request, urllib.error, threading, traceback
        from urllib.parse import urlencode, quote

        # ---------- helpers: logging ----------
        def _log(msg: str):
            try:
                print(msg)
            except Exception:
                pass
            try:
                self.sigLog.emit(msg)
            except Exception:
                pass

        def _log_exc(context: str, exc: Exception):
            try:
                print(f"[ERROR] {context}: {exc.__class__.__name__}: {exc}")
            except Exception:
                pass
            try:
                print(traceback.format_exc())
            except Exception:
                pass
            try:
                if isinstance(exc, urllib.error.HTTPError):
                    code = getattr(exc, 'code', None)
                    body = ""
                    try:
                        body = exc.read().decode('utf-8', 'ignore')
                    except Exception:
                        body = "<no-body>"
                    print(f"[HTTPError] code={code} body:\n{body}\n----")
            except Exception:
                pass
            try:
                self.sigLog.emit(f"❌ {context}: {exc.__class__.__name__}: {exc}")
            except Exception:
                pass

        # ---------- بازسازی صف ----------
        self._rebuild_queue_from_text()

        # جلوگیری از اجرای موازی
        if self._publishing:
            try:
                self.sigToast.emit("در حال تولید هستیم؛ موارد تازه به صف اضافه شد.", "info")
            except Exception:
                pass
            _log("ℹ️ Worker already running.")
            return

        # ---------- اعتبار ----------
        try:
            remaining = int(credits_sync(self.state))
        except Exception as e:
            remaining = 0
            _log_exc("credits_sync", e)

        q_len = len(self._queue)
        if q_len <= 0:
            try:
                self.sigToast.emit("صفی برای تولید وجود ندارد.", "info")
            except Exception:
                pass
            _log("ℹ️ Queue is empty; worker not started.")
            return
        if remaining <= 0:
            try:
                self.sigToast.emit("اعتبار شما صفر است. ابتدا اعتبار تهیه کنید.", "warn")
            except Exception:
                pass
            _log("⚠️ No credits; worker not started.")
            return
        if q_len > remaining:
            try:
                self.sigToast.emit(f"تعداد موارد ({q_len}) بیش از اعتبار ({remaining}) است.", "warn")
            except Exception:
                pass
            _log("⚠️ Queue length exceeds credits; worker not started.")
            return

        # ---------- کلیدها ----------
        api_key = (self.state.get("gemini_api_key") or "").strip() or (self.state.get("api_key") or "").strip()
        if not api_key:
            try:
                self.sigToast.emit("کلید Gemini تنظیم نشده است.", "warn")
            except Exception:
                pass
            _log("⚠️ Missing API key; worker not started.")
            return

        site, user, appp, seo = self._read_wp_config()
        if not (site and user and appp):
            try:
                self.sigToast.emit("اتصال وردپرس کامل نیست (URL/Username/AppPassword).", "warn")
            except Exception:
                pass
            _log("⚠️ WP credentials incomplete; worker not started.")
            return

        # WooCommerce keys (برای محصول)
        wc_key = (self.state.get("wc_consumer_key") or "").strip()
        wc_secret = (self.state.get("wc_consumer_secret") or "").strip()
        # Connector token (برای محصول بدون کلید WC)
        qn_token = (self.state.get("qn_token") or "").strip()

        kind = self._current_kind()
        goal = self._current_goal_key() if kind == "blog" else ""

        # ✅ انتخاب مد محصول: connector / wc / basic
        product_mode = None
        if kind == "product":
            if qn_token:
                product_mode = "connector"
            elif wc_key and wc_secret:
                product_mode = "wc"
            else:
                product_mode = "basic"  # Basic Auth روی /qn/v1/product (با App Password)
                _log("ℹ️ Product mode: BASIC (no qn_token, no wc keys). Using Basic Auth on /qn/v1/product.")

        # ---------- UI state ----------
        self._publishing = True
        try:
            self.btn_run.setEnabled(False)
        except Exception:
            pass
        self.sigBusy.emit(True)
        _log(f"▶️ شروع تولید … (موارد: {q_len})")

        # ---------- helpers: http/meta ----------
        def _http_basic_headers(username: str, app_password: str) -> dict:
            tok = base64.b64encode(f"{username}:{app_password}".encode("utf-8")).decode("ascii")
            return {"Authorization": f"Basic {tok}", "Content-Type": "application/json"}

        def _apply_meta_rank_math(post_id: str, focus_kw: str, meta_desc: str, post_type: str = "post"):
            url = f"{site.rstrip('/')}/wp-json/rmm/v1/update-meta/{post_id}"
            payload = json.dumps({"focus_keyword": focus_kw, "description": meta_desc}).encode("utf-8")
            req = urllib.request.Request(url, data=payload, headers=_http_basic_headers(user, appp), method="POST")
            with urllib.request.urlopen(req, timeout=25) as resp:
                code = resp.getcode()
                if code not in (200, 201):
                    raise urllib.error.HTTPError(url, code, "Unexpected status", hdrs=None, fp=None)

        def _apply_meta_yoast(post_id: str, focus_kw: str, meta_desc: str, post_type: str = "post"):
            import json, urllib.request, urllib.error
            focus_kw_ = (focus_kw or "").strip()
            meta_desc_ = (meta_desc or "").strip()
            if not focus_kw_ and not meta_desc_:
                _log("ℹ️ Yoast meta skipped: both focus_kw and meta_desc are empty.")
                return
            url = f"{site.rstrip('/')}/wp-json/qn/v1/yoast-meta2/{post_id}"
            payload = json.dumps({"focuskw": focus_kw_, "metadesc": meta_desc_, "type": post_type}).encode("utf-8")
            req = urllib.request.Request(url, data=payload, headers=_http_basic_headers(user, appp), method="POST")
            with urllib.request.urlopen(req, timeout=25) as resp:
                code = resp.getcode()
                body = resp.read().decode("utf-8", "ignore")
                _log(f"Yoast set resp: {code} {body[:180]}")
                if code not in (200, 201):
                    raise urllib.error.HTTPError(url, code, f"Unexpected status: {body[:200]}", hdrs=None, fp=None)

        def _update_slug(post_id: str, slug: str, post_type: str = "post"):
            endpoint = "product" if post_type == "product" else "posts"
            url = f"{site.rstrip('/')}/wp-json/wp/v2/{endpoint}/{post_id}"
            payload = json.dumps({"slug": slug}).encode("utf-8")
            req = urllib.request.Request(url, data=payload, headers=_http_basic_headers(user, appp), method="POST")
            with urllib.request.urlopen(req, timeout=25) as resp:
                code = resp.getcode()
                if code not in (200, 201):
                    raise urllib.error.HTTPError(url, code, "Unexpected status", hdrs=None, fp=None)

        def _extract_json(text: str):
            import re, json
            if not text: return None
            s = str(text).strip()
            s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.I)
            s = s.lstrip("\ufeff").rstrip()
            cand = s if (s.startswith("{") and s.endswith("}")) else (
                re.search(r"\{(?:.|\n)*\}", s).group(0) if re.search(r"\{(?:.|\n)*\}", s) else None)
            if not cand: return None
            cand = re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F]", " ", cand)

            def _escape_in_strings(js: str) -> str:
                out = [];
                i = 0;
                n = len(js);
                in_str = False;
                esc = False
                while i < n:
                    ch = js[i]
                    if not in_str:
                        if ch == '"':
                            in_str = True; out.append(ch)
                        else:
                            out.append(ch)
                    else:
                        if esc:
                            out.append(ch); esc = False
                        else:
                            if ch == '\\':
                                esc = True; out.append(ch)
                            elif ch == '"':
                                in_str = False; out.append(ch)
                            else:
                                if ch == '\n':
                                    out.append('\\n')
                                elif ch == '\r':
                                    out.append('\\r')
                                elif ch == '\t':
                                    out.append('\\t')
                                else:
                                    out.append(ch)
                    i += 1
                return "".join(out)

            fx = _escape_in_strings(cand)
            try:
                return json.loads(fx)
            except Exception:
                try:
                    return json.loads(cand)
                except Exception:
                    return None

        # --- Long-Tail & SEO helpers ---
        def _sanitize_kw(s: str) -> str:
            s = (s or "").strip()
            s = re.sub(r"[\"'“”‘’#]+", "", s)
            s = re.sub(r"\s+", " ", s)
            parts = s.split()
            if len(parts) > 6: s = " ".join(parts[:6])
            if len(s) > 80: s = s[:80].rstrip()
            return s

        def _fallback_meta_from_html(html_clean: str) -> str:
            s = re.sub(r"<[^>]+>", " ", html_clean or "", flags=re.S)
            s = html.unescape(re.sub(r"\s+", " ", s)).strip()
            return (s[:160] if len(s) >= 160 else s[:155]).strip()

        def _pick_long_tail(seed: str, obj: dict) -> str:
            primary = _sanitize_kw((obj or {}).get("keyword") or "")
            alts = [(a or "").strip() for a in (obj or {}).get("alt_keywords") or []]
            alts = [_sanitize_kw(a) for a in alts if a]

            def _norm(t: str) -> str:
                t = re.sub(r"[^\w\u0600-\u06FF\s]", " ", t)
                return re.sub(r"\s+", " ", t).strip().lower()

            seed_n = _norm(seed)
            stop = set(["را", "با", "از", "به", "برای", "در", "که", "و", "یا", "هم", "یک", "های", "هایِ"])

            def _score(cand: str) -> tuple:
                words = cand.split()
                len_ok = 3 <= len(words) <= 6
                overlap = sum(1 for w in words if (len(w) > 2 and w not in stop and w in seed_n))
                length_bias = -abs(5 - len(words))
                return (1 if len_ok else 0, overlap, length_bias)

            candidates = []
            if primary: candidates.append(primary)
            candidates += [a for a in alts if a and a not in candidates]
            if not candidates: return ""
            return sorted(candidates, key=_score, reverse=True)[0]

        def _norm_fa(text: str) -> str:
            t = (text or "")
            t = t.replace("\u064a", "\u06cc").replace("\u0643", "\u06a9").replace("\u200c", " ")
            t = re.sub(r"[\u064b-\u0652]", "", t)
            t = re.sub(r"[^\w\u0600-\u06FF\s]", " ", t)
            t = re.sub(r"\s+", " ", t).strip().lower()
            return t

        def _contains_kw(text: str, kw: str) -> bool:
            return _norm_fa(kw) in _norm_fa(text)

        def _ensure_title_has_kw(title: str, kw: str) -> str:
            if not title: title = kw
            if _contains_kw(title, kw): return title
            return f"{kw} — {title}"

        def _ensure_meta_has_kw_once(meta_desc: str, kw: str) -> str:
            if not meta_desc: return f"{kw}؛ راهنمای کوتاه و کاربردی برای نتایج بهتر."
            m = _norm_fa(meta_desc);
            k = _norm_fa(kw);
            count = m.count(k)
            if count == 0:
                if len(meta_desc) < 150: return (meta_desc.rstrip(" .") + f" — {kw}").strip()
                return f"{kw}؛ {meta_desc}"
            elif count > 1:
                parts = re.split(re.escape(kw), meta_desc, flags=re.I)
                return (kw.join(parts[:2]))
            return meta_desc

        def _ensure_intro_has_kw(html_article: str, kw: str) -> str:
            html_article = html_article or "<article></article>"
            m = re.search(r"(?is)<article\b[^>]*>(.*?)</article>", html_article)
            body = m.group(1) if m else html_article
            p = re.search(r"(?is)<p\b[^>]*>(.*?)</p>", body)
            if p:
                first_p = p.group(0)
                if not _contains_kw(first_p, kw):
                    content = re.sub(r"(?is)<p\b[^>]*>(.*?)</p>", f"<p>{kw} — \\1</p>", first_p, count=1)
                    body = body.replace(first_p, content, 1)
            else:
                body = f"<p>{kw} — </p>" + body
            out = re.sub(r"(?is)<article\b[^>]*>.*?</article>", f"<article>{body}</article>", html_article)
            if not re.search(r"(?is)<article\b", out): out = f"<article>{body}</article>"
            return out

        def _ensure_body_uses_kw(html_article: str, kw: str, min_times: int = 3) -> str:
            txt = re.sub(r"(?is)<[^>]+>", " ", html_article or "")
            cur = _norm_fa(txt).count(_norm_fa(kw))
            if cur >= min_times: return html_article
            need = min_times - cur
            body = html_article
            for _ in range(need):
                body = re.sub(r"(?is)</p>", f" — {kw}</p>", body, count=1)
            return body

        def _slugify_fa(kw: str) -> str:
            t = _norm_fa(kw)
            t = re.sub(r"\s+", "-", t)
            t = re.sub(r"-{2,}", "-", t)
            return t.strip("-") or "post"

        # ---------- WooCommerce helpers ----------
        def _wc_request(path: str, payload: dict | None, method: str = "GET"):
            if not (wc_key and wc_secret):
                raise RuntimeError("WooCommerce keys (wc_consumer_key / wc_consumer_secret) تنظیم نشده است.")
            base = f"{site.rstrip('/')}/wp-json/wc/v3{path}"
            qs = urlencode({"consumer_key": wc_key, "consumer_secret": wc_secret})
            url = f"{base}?{qs}"
            data = json.dumps(payload).encode("utf-8") if payload is not None else None
            headers = {"Content-Type": "application/json"}
            req = urllib.request.Request(url, data=data, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=30) as resp:
                code = resp.getcode()
                body = resp.read().decode("utf-8", "ignore")
                if code not in (200, 201):
                    raise urllib.error.HTTPError(url, code, f"Unexpected status: {code}", hdrs=None, fp=None)
                try:
                    return json.loads(body)
                except Exception:
                    return {}

        # ---------- Connector helpers ----------
        def _create_product_via_connector(site_url: str, payload: dict) -> tuple[str, str]:
            import json, time, hmac, hashlib, urllib.request
            token = (self.state.get("qn_token") or "").strip()
            if not token:
                raise RuntimeError("Connector token missing. Pair first.")
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            nonce = hex(int(time.time() * 1000))[2:]
            signature = hmac.new(token.encode("utf-8"), body + nonce.encode("utf-8"), hashlib.sha256).hexdigest()
            url = f"{site_url.rstrip('/')}/wp-json/qn/v1/product"
            headers = {"Content-Type": "application/json", "X-QN-Nonce": nonce, "X-QN-Signature": signature}
            req = urllib.request.Request(url, data=body, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=30) as resp:
                obj = json.loads(resp.read().decode("utf-8", "ignore"))
                if not obj.get("ok"):
                    raise RuntimeError("Product creation failed: " + str(obj))
                return str(obj.get("id") or ""), str(obj.get("permalink") or "")

        def _create_product_via_basic(site_url: str, payload: dict) -> tuple[str, str]:
            """
            محصول از مسیر افزونه با Basic Auth (بدون qn_token و بدون wc_keys).
            نیاز: کاربر وردپرسِ App Password دار، با capability محصول (ادمین یا مدیر فروشگاه).
            """
            import json, urllib.request
            url = f"{site_url.rstrip('/')}/wp-json/qn/v1/product"
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            req = urllib.request.Request(url, data=body, headers=_http_basic_headers(user, appp), method="POST")
            with urllib.request.urlopen(req, timeout=30) as resp:
                obj = json.loads(resp.read().decode("utf-8", "ignore"))
                if not obj.get("ok"):
                    raise RuntimeError("Product creation failed (basic): " + str(obj))
                return str(obj.get("id") or ""), str(obj.get("permalink") or "")

        # ---------- worker ----------
        def worker():
            produced_count = 0
            failed_count = 0

            # فقط برای blog/megapost به کلاس UserWP نیاز داریم
            wp = None
            if kind in ("blog", "megapost"):
                try:
                    wp = UserWP(site, user, appp, seo_plugin=seo)
                except Exception as e:
                    _log_exc("UserWP init", e)
                    failed_count += len(self._queue)
                    self._queue.clear()

            try:
                while self._queue:
                    # اعتبار در حین اجرا
                    try:
                        if int(credits_sync(self.state)) <= 0:
                            try:
                                self.sigToast.emit("اعتبار شما تمام شد. تولید متوقف شد.", "warn")
                            except Exception:
                                pass
                            _log("⚠️ Credits depleted; stopping loop.")
                            break
                    except Exception as e:
                        _log_exc("credits_sync (loop)", e)

                    seed = self._queue.popleft()
                    if seed in self._produced:
                        continue

                    try:
                        _log(f"— تولید: {seed}")
                        prompt = self._build_prompt(kind, seed, goal)
                        try:
                            raw = generate_article(seed, api_key, prompt)
                        except Exception as ge:
                            _log_exc("generate_article", ge)
                            failed_count += 1
                            continue

                        meta_title = seed
                        meta_kw = ""
                        meta_desc = ""
                        html_out = ""
                        obj = _extract_json(raw)
                        if isinstance(obj, dict):
                            try:
                                meta_title = (obj.get("title") or meta_title).strip() or seed
                                picked = _pick_long_tail(seed, obj)
                                meta_kw = _sanitize_kw(picked or (obj.get("keyword") or ""))
                                meta_desc = (obj.get("meta_description") or "").strip()
                                html_out = (obj.get("html") or "").strip()
                            except Exception as pe:
                                _log_exc("parse JSON fields", pe)

                        if not html_out:
                            if isinstance(raw, (bytes, bytearray)):
                                try:
                                    raw = raw.decode("utf-8", "ignore")
                                except Exception:
                                    pass
                            html_out = str(raw or "")

                        html_clean = self._clean_html(html_out)
                        if not meta_kw: meta_kw = _sanitize_kw(seed)
                        if not meta_desc: meta_desc = _fallback_meta_from_html(html_clean)

                        # الزامات سئو
                        meta_title = _ensure_title_has_kw(meta_title, meta_kw)
                        meta_desc = _ensure_meta_has_kw_once(meta_desc, meta_kw)
                        html_clean = _ensure_intro_has_kw(html_clean, meta_kw)
                        html_clean = _ensure_body_uses_kw(html_clean, meta_kw, min_times=3)
                        slug = _slugify_fa(meta_kw)

                        # --- ذخیره در DB (اختیاری) ---
                        # --- ذخیره در DB (اکنون «اجباری با شناسهٔ موقت») ---
                        db_ok = False
                        article_id = None
                        try:
                            # اگر از تب عناوین نیامده باشیم، یک record_id موقت تولید می‌کنیم
                            rid = _ensure_record_id_for_seed(seed)

                            article_id = add_article(
                                record_id=rid,
                                seed=seed,
                                title=meta_title,
                                html=html_clean,
                                status="generated"
                            )
                            db_ok = bool(article_id)

                            # برای سازگاریِ ادامه‌ی فلو، اگر موقتی بود در state هم نگه می‌داریم
                            try:
                                if not (self._current_record_id or "").strip():
                                    self._current_record_id = rid
                            except Exception:
                                pass

                        except Exception as de:
                            _log_exc("add_article", de)  # این خطا مانع ادامهٔ انتشار نمی‌شود

                        # --- ایجاد پیش‌نویس بر اساس نوع ---
                        post_id, wp_url = None, None
                        post_type = "post"
                        try:
                            if kind == "product":
                                post_type = "product"
                                payload = {
                                    "name": meta_title,
                                    "status": "draft",
                                    "slug": slug,
                                    "description": html_clean,
                                    "short_description": meta_desc,
                                }
                                if product_mode == "connector":
                                    post_id, wp_url = _create_product_via_connector(site, payload)
                                elif product_mode == "wc":
                                    res = _wc_request("/products", payload, method="POST")
                                    post_id = str(res.get("id") or "");
                                    wp_url = str(res.get("permalink") or "")
                                else:  # basic
                                    post_id, wp_url = _create_product_via_basic(site, payload)

                                if not post_id:
                                    raise RuntimeError("WooCommerce product creation returned empty id.")
                                _log(f"✅ WooCommerce product created #{post_id}")
                            else:
                                if wp:
                                    try:
                                        try:
                                            res = wp.create_post(meta_title, html_clean, status="draft", slug=slug)
                                        except TypeError:
                                            res = wp.create_post(meta_title, html_clean, status="draft")
                                        if isinstance(res, dict):
                                            post_id = str(res.get("id") or "")
                                            wp_url = str(
                                                res.get("link") or res.get("guid", {}).get("rendered", "") or "")
                                            if not post_id:
                                                raise RuntimeError("WP create_post returned no id.")
                                    except Exception as we:
                                        _log_exc("wp.create_post", we)
                        except Exception as ce:
                            _log_exc("create (post/product)", ce)

                        # --- گیت موفقیت ---
                        success = bool(post_id or wp_url)
                        if not success:
                            failed_count += 1
                            _log("❌ ایجاد پست/محصول ناموفق بود؛ این آیتم به‌عنوان خطا ثبت شد.")
                            continue

                        # اسلاگ (اگر لازم)
                        try:
                            if post_id and slug and wp_url and slug not in (wp_url or ""):
                                _update_slug(post_id, slug, post_type=post_type)
                                _log(f"✅ Slug set: /{slug}")
                        except Exception as ue:
                            _log_exc("update slug", ue)

                        # متای سئو
                        try:
                            if seo == "rank-math":
                                _log(f"RankMath payload: kw='{meta_kw}' desc_len={len(meta_desc or '')}")
                                _apply_meta_rank_math(post_id, meta_kw, meta_desc, post_type=post_type)
                                _log(f"✅ Rank Math meta set for {post_type} #{post_id}")
                            elif seo == "yoast":
                                _log(f"Yoast payload: kw='{meta_kw}' desc_len={len(meta_desc or '')}")
                                try:
                                    _apply_meta_yoast(post_id, meta_kw, meta_desc, post_type=post_type)
                                    _log(f"✅ Yoast meta set for {post_type} #{post_id}")
                                except Exception as ye:
                                    _log_exc("Yoast meta", ye)
                            else:
                                _log("ℹ️ افزونهٔ سئو روی 'none' است؛ متا اعمال نشد.")
                        except Exception as e:
                            _log_exc("SEO meta", e)

                        # بروزرسانی DB فقط اگر قبلاً ذخیره شده بود
                        if db_ok and article_id:
                            try:
                                update_article_status(article_id, "published", wp_post_id=post_id, wp_url=wp_url)
                            except Exception as ue:
                                _log_exc("update_article_status", ue)

                        # کسر اعتبار فقط روی موفقیت
                        try:
                            new_display = credits_consume(self.state, 1)
                            try:
                                self.sigCreditsChanged.emit(int(new_display))
                            except Exception:
                                pass
                        except Exception as ce:
                            _log_exc("credits_consume", ce)

                        # موفقیت واقعی:
                        produced_count += 1
                        try:
                            self.sigArticleReady.emit({
                                "record_id": self._current_record_id or "",
                                "seed": seed,
                                "post_id": post_id or "",
                                "wp_url": wp_url or "",
                                "keyword": meta_kw,
                                "meta_description": meta_desc,
                                "title": meta_title
                            })
                        except Exception as se:
                            _log_exc("sigArticleReady emit", se)

                        try:
                            self.sigRemoveSeed.emit(seed)
                        except Exception as se:
                            _log_exc("sigRemoveSeed emit", se)

                        # اطلاع به تب عناوین
                        try:
                            from PySide6.QtWidgets import QTabWidget
                            from .titles_tab import TitlesTab
                            tabw = None;
                            p = self.parent()
                            while p is not None and tabw is None:
                                if isinstance(p, QTabWidget): tabw = p; break
                                p = p.parent()
                            if tabw is not None:
                                titles_tab = None
                                for i in range(tabw.count()):
                                    w = tabw.widget(i)
                                    if isinstance(w, TitlesTab) or getattr(w.__class__, "__name__", "") == "TitlesTab":
                                        titles_tab = w;
                                        break
                                if titles_tab is not None and hasattr(titles_tab, "on_article_generated"):
                                    titles_tab.on_article_generated(self._current_record_id or "", seed)
                        except Exception as nt:
                            _log_exc("notify TitlesTab", nt)

                        self._produced.add(seed)
                        _log(f"✅ پیش‌نویس ایجاد شد ({post_id}).")

                    except Exception as e:
                        failed_count += 1
                        _log_exc("worker item", e)

                # جمع‌بندی
                if produced_count > 0 and failed_count == 0:
                    try:
                        self.sigToast.emit("تمام آیتم‌ها با موفقیت ایجاد شدند.", "info")
                    except Exception:
                        pass
                elif produced_count > 0 and failed_count > 0:
                    try:
                        self.sigToast.emit(f"برخی موفق، برخی ناموفق — موفق: {produced_count} / خطا: {failed_count}",
                                           "warn")
                    except Exception:
                        pass
                else:
                    try:
                        self.sigToast.emit("تمام آیتم‌ها ناموفق بودند.", "warn")
                    except Exception:
                        pass
                _log(f"⏹ پایان صف — موفق: {produced_count} / خطا: {failed_count}")

            finally:
                self._publishing = False
                try:
                    self.btn_run.setEnabled(True)
                except Exception:
                    pass
                self.sigBusy.emit(False)

        # start worker
        try:
            threading.Thread(target=worker, daemon=True).start()
        except Exception as e:
            _log_exc("start thread", e)
            self._publishing = False
            try:
                self.btn_run.setEnabled(True)
            except Exception:
                pass
            self.sigBusy.emit(False)

    def _read_wp_config(self) -> tuple[str, str, str, str]:
        """
        برمی‌گرداند: (site, user, appp, seo)
        - با هر دو ساختار state سازگار است:
          a) کلیدهای تکی: wp_url / wp_user / wp_app_pass / seo_plugin
          b) دیکشنری wp_target: {url, username, app_password, seo_plugin}
        - seo را نرمال می‌کند به: 'none' / 'rank-math' / 'yoast'
        """

        def _S(key, default=""):
            try:
                from quiknote.storage_sqlite import get_setting
                v = self.state.get(key)
                if v in (None, ""):
                    v = get_setting(key, default)
                return (v or default)
            except Exception:
                return (self.state.get(key) or default)

        wp_cfg = self.state.get("wp_target") or {}
        if not wp_cfg:
            wp_cfg = {
                "url": (_S("wp_url", "") or "").strip(),
                "username": (_S("wp_user", "") or "").strip(),
                "app_password": (_S("wp_app_pass", "") or "").strip(),
                "seo_plugin": (_S("seo_plugin", "none") or "none").strip().lower(),
            }

        site = (wp_cfg.get("url") or "").strip()
        user = (wp_cfg.get("username") or "").strip()
        appp = (wp_cfg.get("app_password") or "").strip()

        seo = (wp_cfg.get("seo_plugin") or "none").strip().lower()
        if seo == "rankmath":
            seo = "rank-math"
        elif seo not in ("none", "rank-math", "yoast"):
            seo = "none"

        return site, user, appp, seo


    # ---------- تست سرور ----------
    def _on_test_gemini(self):
        try:
            api_key = (self.state.get("gemini_api_key") or "").strip()
        except Exception:
            api_key = ""
        if not api_key:
            self.sigToast.emit("کلید Gemini تنظیم نشده است.", "warn")
            return

        if self._test_thread and self._test_thread.is_alive():
            self.sigToast.emit("تست در حال اجراست…", "info")
            return

        self.btn_test.setEnabled(False)

        def _ensure_record_id_for_seed(seed: str) -> str:
            """
            اگر self._current_record_id خالی باشد، برای همین seed یک شناسه‌ی موقتی می‌سازیم
            تا add_article بتواند ذخیره کند. برای هر seed ثابت می‌ماند (memoize).
            """
            rid = (self._current_record_id or "").strip()
            if rid:
                return rid

            if not hasattr(self, "_adhoc_rids") or not isinstance(getattr(self, "_adhoc_rids"), dict):
                self._adhoc_rids = {}

            if seed not in self._adhoc_rids:
                import time, hashlib
                # شناسه‌ی فشرده و پایدار بر اساس seed + زمان (برای کاهش برخورد)
                h = hashlib.sha1(seed.encode("utf-8")).hexdigest()[:8]
                self._adhoc_rids[seed] = f"adhoc:{int(time.time())}:{h}"

            return self._adhoc_rids[seed]


        def worker():
            try:
                url = "https://generativelanguage.googleapis.com/v1beta/models"
                req = urllib.request.Request(url, method="GET", headers={
                    "x-goog-api-key": api_key,
                    "accept": "application/json",
                    "user-agent": "QuikNote/1.0 (ArticleTab Test)"
                })
                with urllib.request.urlopen(req, timeout=7) as resp:
                    code = resp.getcode()
                    if 200 <= code < 300:
                        self.sigToast.emit("اتصال برقرار است.", "info")
                    else:
                        self.sigToast.emit(f"پاسخ غیرمنتظره از سرور: HTTP {code}", "warn")
            except urllib.error.HTTPError as he:
                if he.code == 403:
                    self.sigToast.emit("عدم دسترسی (HTTP 403). کلید/دسترسی را بررسی کنید.", "error")
                elif he.code == 401:
                    self.sigToast.emit("Unauthorized (HTTP 401). کلید نامعتبر است.", "error")
                else:
                    self.sigToast.emit(f"HTTP {he.code}", "error")
            except urllib.error.URLError as ue:
                self.sigToast.emit(f"عدم‌دسترسی به اینترنت/سرور: {ue.reason}", "error")
            except Exception as e:
                self.sigToast.emit(str(e), "error")
            finally:
                QTimer.singleShot(0, lambda: self.btn_test.setEnabled(True))

        self._test_thread = threading.Thread(target=worker, daemon=True)
        self._test_thread.start()

    # ---------- اسلات‌های UI ----------
    @Slot(str)
    def _append_log(self, s: str):
        try:
            self.txt_log.append(humanize_error(str(s)))
        except Exception:
            pass

    @Slot(bool)
    def _toggle_overlay_safe(self, on: bool):
        def _do():
            try:
                self._ensure_overlay()
                self._overlay.show_overlay(bool(on))
            except Exception:
                pass
        QTimer.singleShot(0, _do)

    @Slot(str)
    def _remove_seed_line(self, seed: str):
        try:
            lines = [ln for ln in self.txt_seeds.toPlainText().splitlines()]
            seed_norm = (seed or '').strip()
            new_lines = [ln for ln in lines if ln.strip() != seed_norm]
            if len(new_lines) != len(lines):
                self.txt_seeds.setPlainText("\n".join([ln for ln in new_lines if ln.strip()]))
        except Exception:
            pass
