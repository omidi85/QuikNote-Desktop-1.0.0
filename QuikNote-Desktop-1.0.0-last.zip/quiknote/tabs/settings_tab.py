# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Dict, Any
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox,
    QLabel, QLineEdit, QPushButton, QMessageBox, QComboBox, QFileDialog
)
from PySide6.QtCore import Qt, Signal

from ..storage_sqlite import get_setting, set_setting

# اگر ماژول credits در پروژه باشد، استفاده می‌کنیم تا دوگانگی پیش نیاید
try:
    from ..credits import get as credits_get, sync_from_server
except Exception:
    # fallback ساده اگر ماژول در دسترس نبود
    def credits_get(state: dict) -> int:
        val = get_setting("credits_cache", 0)
        try:
            return int(val or 0)
        except Exception:
            return 0
    def sync_from_server(state: dict) -> int:
        # در حالت fallback، فقط همان کش را برمی‌گردانیم
        return credits_get(state)

CENTRAL_SITE_BASE = "https://quiknote.ir"

def _load_state_from_db() -> dict:
    """بارگذاری تنظیمات از SQLite با پیش‌فرض‌های امن"""
    keys = [
        'central_url','central_email','central_password',
        'wp_target','gemini_api_key','gemini_model',
        'branding','pixabay_api_key'
    ]
    st = {}
    for k in keys:
        st[k] = get_setting(k, None)
    # پیش‌فرض‌ها
    st.setdefault('central_url', CENTRAL_SITE_BASE)
    st.setdefault('central_email','')
    st.setdefault('central_password','')
    st.setdefault('wp_target', {'url':'','username':'','app_password':'','seo_plugin':'none'})
    st.setdefault('gemini_api_key','')
    st.setdefault('gemini_model','gemini-2.5-flash')
    st.setdefault('branding', {'logo_path':'','font_path':''})
    st.setdefault('pixabay_api_key','')
    return st

def _save_state_to_db(state: dict) -> None:
    """ذخیرهٔ اتمیک تنظیمات در SQLite"""
    for k, v in state.items():
        set_setting(k, v)

class SettingsTab(QWidget):
    """
    تب تنظیمات — ذخیره در SQLite؛ اعتبار (Credits) فقط از سرور خوانده می‌شود تا دوگانگی ایجاد نشود.
    امضای سازنده سازگار با app.py: SettingsTab(self.state, self)
    """
    sigSaved = Signal()
    sigCreditsChanged = Signal(int)

    # مهم: امضای مورد انتظار app.py → (state, parent)
    def __init__(self, state: Dict[str, Any] | None = None, parent=None):
        super().__init__(parent)

        # self.state اشاره به دیکشنری اصلی برنامه (در حالتی که از app پاس داده شود)
        # اگر state داده نشود، از DB می‌خوانیم.
        db_state = _load_state_from_db()
        if isinstance(state, dict):
            # مقدارهای موجود در state بیرونی را نگه می‌داریم؛ باقی را از DB پر می‌کنیم
            for k, v in db_state.items():
                state.setdefault(k, v)
            self.state: Dict[str, Any] = state  # اشاره مستقیم به دیکشنری app
        else:
            self.state = db_state

        self._build_ui()
        self._populate_from_state()

    # ---------- UI ----------
    def _build_ui(self):
        self.setLayoutDirection(Qt.RightToLeft)
        root = QVBoxLayout(self)
        root.setContentsMargins(16,16,16,16)
        root.setSpacing(14)

        row = QHBoxLayout()
        row.setSpacing(16)

        # --- حساب مرکزی ---
        acc_box = QGroupBox('حساب کاربری (سایت مرکزی)')
        acc_form = QFormLayout()
        acc_form.setLabelAlignment(Qt.AlignRight)

        self.lbl_server = QLabel("سرور: متصل")
        self.inp_email = QLineEdit(self.state.get('central_email',''))
        self.inp_pass  = QLineEdit(self.state.get('central_password',''))
        self.inp_pass.setEchoMode(QLineEdit.Password)

        try:
            init_credits = credits_get(self._compose_state_for_server())
        except Exception:
            init_credits = get_setting("credits_cache", 0) or 0
        self.lbl_credits = QLabel(str(init_credits))

        self.btn_refresh = QPushButton('بروزرسانی اطلاعات از سرور')
        self.btn_refresh.clicked.connect(self._refresh_from_server)

        acc_form.addRow('وضعیت سرور', self.lbl_server)
        acc_form.addRow('ایمیل', self.inp_email)
        acc_form.addRow('رمز عبور', self.inp_pass)
        acc_form.addRow('مقالات باقی‌مانده', self.lbl_credits)
        acc_form.addRow('', self.btn_refresh)
        acc_box.setLayout(acc_form)

        # --- سایت وردپرس + Gemini ---
        wp_box = QGroupBox('سایت مقصد (وردپرس)')
        wp_form = QFormLayout()
        wp_form.setLabelAlignment(Qt.AlignRight)

        wp = self.state.get('wp_target') or {}
        self.inp_wp_url  = QLineEdit(wp.get('url',''))
        self.inp_wp_user = QLineEdit(wp.get('username',''))
        self.inp_wp_app  = QLineEdit(wp.get('app_password',''))
        self.inp_wp_app.setEchoMode(QLineEdit.Password)

        self.sel_seo = QComboBox()
        self.sel_seo.addItems(['none','rankmath','yoast'])
        idx = {'none':0,'rankmath':1,'yoast':2}.get(wp.get('seo_plugin','none'),0)
        self.sel_seo.setCurrentIndex(idx)

        self.inp_gemini = QLineEdit(self.state.get('gemini_api_key',''))
        self.inp_gemini.setEchoMode(QLineEdit.Password)

        wp_form.addRow('آدرس سایت کاربر', self.inp_wp_url)
        wp_form.addRow('نام کاربری', self.inp_wp_user)
        wp_form.addRow('App Password', self.inp_wp_app)
        wp_form.addRow('افزونه سئو', self.sel_seo)
        wp_form.addRow('کلید Gemini', self.inp_gemini)
        wp_box.setLayout(wp_form)

        # --- ذخیره ---
        save_row = QHBoxLayout()
        save_row.addStretch(1)
        self.btn_save = QPushButton('ذخیره تنظیمات')
        self.btn_save.clicked.connect(self._save)
        save_row.addWidget(self.btn_save, 0, Qt.AlignLeft)

        row.addWidget(acc_box, 1)
        row.addWidget(wp_box, 1)
        root.addLayout(row)
        root.addLayout(save_row)

    # ---------- Helper ----------
    def _compose_state_for_server(self) -> dict:
        """State لازم برای درخواست‌های سرور (credits و غیره)"""
        return {
            'central_url': CENTRAL_SITE_BASE,
            'central_email': self.state.get('central_email',''),
            'central_password': self.state.get('central_password','')
        }

    def _populate_from_state(self):
        self.inp_email.setText(self.state.get('central_email',''))
        self.inp_pass.setText(self.state.get('central_password',''))

        try:
            self.lbl_credits.setText(str(credits_get(self._compose_state_for_server())))
        except Exception:
            self.lbl_credits.setText(str(get_setting("credits_cache", 0) or 0))

        wp = self.state.get('wp_target') or {}
        self.inp_wp_url.setText(wp.get('url',''))
        self.inp_wp_user.setText(wp.get('username',''))
        self.inp_wp_app.setText(wp.get('app_password',''))
        try:
            self.sel_seo.setCurrentIndex({'none':0,'rankmath':1,'yoast':2}[wp.get('seo_plugin','none')])
        except Exception:
            pass

        self.inp_gemini.setText(self.state.get('gemini_api_key',''))


    # ---------- Actions ----------
    def _pick_logo(self):
        path, _ = QFileDialog.getOpenFileName(self, 'انتخاب فایل لوگو', '', 'Images (*.png *.jpg *.jpeg *.webp)')
        if path:
            self.inp_logo.setText(path)

    def _pick_font(self):
        path, _ = QFileDialog.getOpenFileName(self, 'انتخاب فایل فونت', '', 'Fonts (*.ttf *.otf)')
        if path:
            self.inp_font.setText(path)

    def _refresh_from_server(self):
        # آپدیت state لوکال از فیلدهای فرم
        self.state['central_email'] = (self.inp_email.text() or '').strip()
        self.state['central_password'] = (self.inp_pass.text() or '').strip()
        # ذخیرهٔ آنی در DB (بدون تغییر سایر بخش‌ها)
        _save_state_to_db({
            'central_email': self.state['central_email'],
            'central_password': self.state['central_password'],
            'central_url': CENTRAL_SITE_BASE,
        })

        try:
            # از سرور اعتبار را بخوان
            new_val = sync_from_server(self._compose_state_for_server())
            if new_val is not None:
                self.lbl_credits.setText(str(new_val))
                set_setting("credits_cache", int(new_val))
                self.sigCreditsChanged.emit(int(new_val))
                QMessageBox.information(self, 'موفق', 'اطلاعات حساب و اعتبار بروز شد.')
            else:
                QMessageBox.warning(self, 'هشدار', 'عدم توانایی در دریافت اعتبار از سرور.')
        except Exception as e:
            QMessageBox.warning(self, 'هشدار', f'عدم توانایی در دریافت اعتبار از سرور:\n{e}')

    def _save(self):
        self.state['central_url'] = CENTRAL_SITE_BASE
        self.state['central_email'] = (self.inp_email.text() or '').strip()
        self.state['central_password'] = (self.inp_pass.text() or '').strip()

        self.state['wp_target'] = {
            'url': (self.inp_wp_url.text() or '').strip(),
            'username': (self.inp_wp_user.text() or '').strip(),
            'app_password': (self.inp_wp_app.text() or '').strip(),
            'seo_plugin': {0:'none',1:'rankmath',2:'yoast'}[self.sel_seo.currentIndex()],
        }

        # حذف logo / font / pixabay
        self.state.pop('branding', None)
        self.state.pop('pixabay_api_key', None)

        self.state['gemini_api_key']  = (self.inp_gemini.text() or '').strip()

        _save_state_to_db(self.state)
        self.sigSaved.emit()
        QMessageBox.information(self, 'موفق', 'تنظیمات ذخیره شد.')
