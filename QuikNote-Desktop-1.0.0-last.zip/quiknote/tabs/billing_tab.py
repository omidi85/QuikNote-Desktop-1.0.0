
# -*- coding: utf-8 -*-
from __future__ import annotations
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QLabel)
from PySide6.QtCore import Qt

class BillingTab(QWidget):
    def __init__(self, state: dict, parent=None):
        super().__init__(parent)
        self.state = state
        self._build_ui()

    def _build_ui(self):
        self.setLayoutDirection(Qt.RightToLeft)
        v = QVBoxLayout(self)
        v.setContentsMargins(20,20,20,20)
        v.setSpacing(12)

        url = "https://quiknote.ir/shop/"
        lbl = QLabel(f"<div dir='rtl' style='text-align:center'>برای خرید اشتراک روی این لینک کلیک کنید:<br><a href='{url}'>{url}</a></div>")
        lbl.setTextFormat(Qt.RichText)
        lbl.setOpenExternalLinks(True)
        lbl.setAlignment(Qt.AlignCenter)
        v.addStretch(1)
        v.addWidget(lbl)
        v.addStretch(1)
