# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import Optional, Any
import datetime
import sys

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QGroupBox,
    QGridLayout, QLineEdit, QMessageBox
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QGuiApplication, QClipboard  # 👈 برای کلیپ‌بورد

from ..api import CentralAPI
from ..storage import save
from ..credits import set as credits_set, get as credits_get
from ..hwid import get_hwid, get_hwid_legacy
from ..ui_overlays import OverlayManager

# اضافه برای اجرای کارها در پس‌زمینه (بدون قفل UI)
from ..utils.threads import Worker, thread_pool


class DashboardTab(QWidget):
    """
    داشبورد ساده:
      - نمایش: اعتبار مقاله، نام پلن، اعتبار معرفی، تعداد معرفی، «روزهای مانده»
      - تاریخ انقضا نمایش داده نمی‌شود
      - هشدار بالاسری بر اساس اعتبار کم یا روزهای مانده کم
    """
    def __init__(self, state: dict, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.state = state
        self._built = False
        self._first_server_check_done = False
        self._overlay: Optional[OverlayManager] = None

        self._build_ui()
        QTimer.singleShot(0, self._refresh)

    # ---------- UI ----------
    def _build_ui(self):
        if self._built:
            return
        self._built = True

        v = QVBoxLayout(self)
        v.setContentsMargins(16, 16, 16, 16)
        v.setSpacing(12)

        grid = QGridLayout()
        grid.setHorizontalSpacing(16)
        grid.setVerticalSpacing(12)

        # کارت‌ها
        self.card_articles     = self._make_card('اعتبار مقاله', str(credits_get(self.state)))
        self.card_plan         = self._make_card('پلن (نام محصول)', self.state.get('plan', '—'))
        self.card_ref_credits  = self._make_card('اعتبار معرفی', '0')
        self.card_ref_count    = self._make_card('تعداد معرفی', '0')
        self.card_days_left    = self._make_card('روزهای مانده', '—')  # تاریخ انقضا حذف شد

        grid.addWidget(self.card_articles,    0, 0)
        grid.addWidget(self.card_plan,        0, 1)
        grid.addWidget(self.card_ref_credits, 1, 0)
        grid.addWidget(self.card_ref_count,   1, 1)
        grid.addWidget(self.card_days_left,   2, 0, 1, 2)  # تمام عرض ردیف

        v.addLayout(grid)

        # لینک معرفی
        box = QGroupBox('لینک معرفی')
        lay = QHBoxLayout(box)
        self.inp_ref_link = QLineEdit(self.state.get('referral_link', ''))
        self.inp_ref_link.setReadOnly(True)
        btn_copy = QPushButton('کپی')
        btn_copy.clicked.connect(lambda: self._copy(self.inp_ref_link.text()))
        lay.addWidget(self.inp_ref_link, 1)
        lay.addWidget(btn_copy, 0)
        v.addWidget(box)

        # دکمه بروزرسانی
        btnr = QPushButton('بروزرسانی')
        btnr.clicked.connect(self._refresh)
        v.addWidget(btnr, alignment=Qt.AlignLeft)

        v.addStretch(1)

    def _make_card(self, title: str, value: str) -> QGroupBox:
        g = QGroupBox(title)
        l = QVBoxLayout(g)
        l.setContentsMargins(12, 10, 12, 10)
        lbl = QLabel(str(value))
        lbl.setAlignment(Qt.AlignCenter)
        lbl.setObjectName('value_label')
        g._value_label = lbl
        l.addWidget(lbl)
        return g

    # ---------- Helpers ----------
    def _api(self) -> CentralAPI:
        # زمان انتظار کوتاه‌تر برای جلوگیری از قفل UI
        return CentralAPI(
            self.state.get('central_url', ''),
            self.state.get('central_email', ''),
            self.state.get('central_password', ''),
            timeout=8.0
        )

    def _overlay_mgr(self) -> OverlayManager:
        if not self._overlay:
            self._overlay = OverlayManager(self.window())
        return self._overlay

    def _register_hwid_once(self, api: CentralAPI):
        """
        نسخهٔ Async: همان نام قبلی برای سازگاری با کد موجود.
        """
        if self.state.get('_hwid_registered_ok'):
            return

        def job():
            try:
                hw = self.state.get('_cached_hwid')
                hw_legacy = self.state.get('_cached_hwid_legacy')
                if not hw or not hw_legacy:
                    hw = get_hwid()
                    hw_legacy = get_hwid_legacy()
                api.hwid_register(hw, hw_legacy)
                return {"ok": True, "hw": hw, "legacy": hw_legacy}
            except Exception as e:
                return {"ok": False, "err": e}

        w = Worker(job)
        def done(res, err):
            if not err and isinstance(res, dict) and res.get("ok"):
                self.state['_cached_hwid'] = res["hw"]
                self.state['_cached_hwid_legacy'] = res["legacy"]
                self.state['_hwid_registered_ok'] = True
                save(self.state)
        w.signals.done.connect(done)
        thread_pool.start(w)

    def _copy(self, text: str):
        """
        کپی مطمئن به کلیپ‌بورد سیستم:
         1) QGuiApplication.clipboard()
         2) در صورت نیاز، کپی از QLineEdit به‌عنوان fallback
         3) تأیید اینکه واقعاً کپی شده؛ در غیر این صورت پیام خطا
        """
        if not text:
            QMessageBox.warning(self, 'خطا', 'لینک خالی است.')
            return

        ok = False
        try:
            cb = QGuiApplication.clipboard()
            cb.setText(text, QClipboard.Clipboard)
            # برای لینوکس/X11 (اختیاری، روی ویندوز/مک اثری ندارد)
            try:
                cb.setText(text, QClipboard.Selection)
            except Exception:
                pass
            ok = (cb.text(QClipboard.Clipboard) == text)
        except Exception:
            ok = False

        if not ok:
            # fallback: از خود ویجت کپی بگیر
            try:
                self.inp_ref_link.setFocus()
                self.inp_ref_link.selectAll()
                self.inp_ref_link.copy()
                cb = QGuiApplication.clipboard()
                ok = (cb.text(QClipboard.Clipboard) == text)
            except Exception:
                ok = False

        if ok:
            QMessageBox.information(self, 'کپی شد', 'لینک در کلیپ‌بورد قرار گرفت.')
        else:
            QMessageBox.warning(self, 'خطا', 'نتوانستم لینک را در کلیپ‌بورد قرار دهم. لطفاً دستی کپی کنید.')

    # --- Date parsing util (فقط برای محاسبه days_left در صورت نبود مقدار از سرور) ---
    def _parse_expire_to_datetime(self, raw: Any) -> Optional[datetime.datetime]:
        """
        raw می‌تواند:
          - timestamp ثانیه‌ای/میلی‌ثانیه‌ای (str/int)
          - 'YYYY-MM-DD' یا 'YYYY/MM/DD' یا ISO-8601
        خروجی: datetime (local) یا None
        """
        if raw in (None, '', '—'):
            return None
        try:
            # عددی؟
            if isinstance(raw, (int, float)) or (isinstance(raw, str) and raw.isdigit()):
                ts = int(raw)
                if ts > 10_000_000_000:  # میلی‌ثانیه
                    ts //= 1000
                return datetime.datetime.fromtimestamp(ts)
            # رشته
            if isinstance(raw, str):
                s = raw.strip()
                for fmt in ("%Y-%m-%d", "%Y/%m/%d"):
                    try:
                        return datetime.datetime.strptime(s, fmt)
                    except Exception:
                        pass
                try:
                    return datetime.datetime.fromisoformat(s)
                except Exception:
                    pass
        except Exception:
            return None
        return None

    # ---------- Refresh ----------
    def _refresh(self):
        """
        نسخهٔ Async: UI فوراً برمی‌گردد؛ داده بعد از آماده شدن ست می‌شود.
        """
        try:
            api = self._api()

            # ثبت HWID به صورت موازی (اگر لازم باشد)
            self._register_hwid_once(api)

            # دکمه را موقتاً غیرفعال کن
            try:
                # پیدا کردن دکمه‌ی بروزرسانی در بچه‌ها
                for i in range(self.layout().count()):
                    item = self.layout().itemAt(i)
                    w = item.widget()
                    if isinstance(w, QPushButton) and w.text() in ('بروزرسانی', 'در حال به‌روزرسانی...'):
                        w.setEnabled(False)
                        w.setText('در حال به‌روزرسانی...')
                        self._btn_refresh_ref = w
                        break
            except Exception:
                self._btn_refresh_ref = None

            def job():
                # شبکه خارج از UI
                prof = api.profile()
                srv_notifs = {}
                try:
                    srv_notifs = api.notifications() or {}
                except Exception:
                    srv_notifs = {}
                return {"prof": prof, "srv": srv_notifs}

            w = Worker(job)
            w.signals.done.connect(self._on_refresh_done)
            thread_pool.start(w)

        except Exception as e:
            try:
                QMessageBox.warning(self, 'خطا', f'مشکل در آغاز به‌روزرسانی: {e}')
            except Exception:
                pass

    def _on_refresh_done(self, res, err):
        # برگرداندن وضعیت دکمه
        try:
            if getattr(self, '_btn_refresh_ref', None):
                self._btn_refresh_ref.setEnabled(True)
                self._btn_refresh_ref.setText('بروزرسانی')
        except Exception:
            pass

        if err or not isinstance(res, dict):
            return

        prof = res.get("prof") or {}
        srv = res.get("srv") or {}

        try:
            u = prof['user'] if isinstance(prof, dict) and isinstance(prof.get('user'), dict) else (prof if isinstance(prof, dict) else {})

            ref_credits = u.get('referral_credits') or u.get('credits_referral') or 0
            referred    = u.get('referred_count')   or u.get('referral_count')  or 0
            plan        = u.get('plan')             or u.get('plan_name')       or self.state.get('plan', '—')
            articles    = u.get('article_credits')  or u.get('credits_articles') or u.get('credits') or 0
            ref_link    = u.get('referral_link')    or self.state.get('referral_link', '')

            # فقط days_left را نمایش می‌دهیم؛ اگر نیامده بود، محاسبه می‌کنیم
            days_left = u.get('days_left') if u.get('days_left') is not None else u.get('expiry_days_left')
            if days_left is None:
                expire_raw = u.get('expire_at_greg') or u.get('expire_at') or u.get('expiry_date')
                dt = self._parse_expire_to_datetime(expire_raw)
                if dt:
                    today = datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
                    exp0  = dt.replace(hour=0, minute=0, second=0, microsecond=0)
                    days_left = (exp0 - today).days

            # ذخیره‌ی موارد لازم (بدون ذخیره تاریخ)
            credits_set(self.state, int(articles))
            if plan:
                self.state['plan'] = plan
            if ref_link:
                self.state['referral_link'] = ref_link
            if days_left is not None:
                try:
                    self.state['days_left'] = int(days_left)
                except Exception:
                    pass
            save(self.state)

            # UI
            self.card_ref_credits._value_label.setText(f"{int(ref_credits)} اعتبار")
            self.card_ref_count._value_label.setText(str(int(referred)))
            self.card_plan._value_label.setText(str(plan))
            self.card_articles._value_label.setText(str(articles))
            self.card_days_left._value_label.setText(str(days_left if days_left is not None else '—'))

            base = self.state.get('central_url', '')

            # هشدار بالاسری: اگر اعتبار < 10 یا روزهای مانده < 7
            try:
                credits_val = int(articles)
            except Exception:
                credits_val = 0
            dl_val = None
            try:
                dl_val = int(days_left) if days_left is not None else None
            except Exception:
                dl_val = None

            if (credits_val < 10) or (dl_val is not None and dl_val < 7):
                parts = [f"اعتبار: {credits_val}"]
                if dl_val is not None:
                    parts.append(f"روزهای مانده: {dl_val}")
                warning_text = " ، ".join(parts) + " — لطفاً برای جلوگیری از توقف، تمدید/خرید انجام دهید.⚠️"
                self._overlay_mgr().show_top_warning(warning_text, base)
            else:
                self._overlay_mgr().clear_top_warning()

            # نوتیف‌های سرور (فقط یک‌بار)
            if not self._first_server_check_done:
                self._first_server_check_done = True
                server_notifs = []
                for src_key in ("alerts", "offers", "custom"):
                    for item in (srv.get(src_key) or []):
                        if not isinstance(item, dict):
                            continue
                        server_notifs.append({
                            "type": item.get("type") or ("offer" if src_key == "offers" else "info"),
                            "title": item.get("title") or "اطلاع‌رسانی",
                            "message": item.get("message") or "",
                            "cta": item.get("cta") or {},
                        })
                self._overlay_mgr().enqueue(server_notifs, base)

        except Exception:
            pass
