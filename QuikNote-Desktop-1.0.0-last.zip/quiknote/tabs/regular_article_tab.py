# filepath: c:\Users\1402\autotranslate\QuikNote-Desktop-1.0.0\quiknote\tabs\regular_article_tab.py
# -*- coding: utf-8 -*-
from __future__ import annotations
import os, re, json, threading, ast
from urllib.parse import urlparse

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QProgressBar, QMessageBox, QGroupBox
)
from PySide6.QtCore import Qt, Signal, Slot

from ..gemini import generate_article, GeminiError
from ..wp_client import UserWP
from ..image_builder import compose_feature_image
from ..wp_media import upload_media, set_featured_image
from ..credits import consume as credits_consume

URL_RE = re.compile(r"^https?://", re.I)

# فقط حروف انگلیسی و فاصله؛ برای Pixabay هر چیز دیگری را حذف می‌کنیم
WORD_RE = re.compile(r"[A-Za-z]+")
ALLOWED_CHARS_RE = re.compile(r"[^A-Za-z ]+")


class RegularArticleTab(QWidget):
    # سیگنال‌ها
    sigLog = Signal(str)
    sigArticleReady = Signal(str)
    sigProgress = Signal(int)
    sigInfo = Signal(str, str)
    sigWarn = Signal(str, str)
    sigError = Signal(str, str)
    sigCreditsChanged = Signal(int)
    sigPublishEnable = Signal(bool, bool)
    sigResetAfterSuccess = Signal()

    def __init__(self, state: dict, parent=None):
        super().__init__(parent)
        self.state = state or {}
        self._publishing = False
        self._article_meta = {}  # {"title","long_tail_keyword","image_query_en","meta_description"}
        self._build_ui()

        # اتصال سیگنال‌ها
        self.sigLog.connect(self._append_log)
        self.sigArticleReady.connect(self._on_article)
        self.sigProgress.connect(self._on_progress)
        self.sigInfo.connect(self._on_info)
        self.sigWarn.connect(self._on_warn)
        self.sigError.connect(self._on_error)
        self.sigPublishEnable.connect(self._set_publish_enabled)
        self.sigResetAfterSuccess.connect(self._reset_after_success)

    # ------------------ UI ------------------
    def _build_ui(self):
        v = QVBoxLayout(self)
        v.setContentsMargins(20, 20, 20, 20)
        v.setSpacing(12)

        form = QFormLayout()
        self.inp_seed = QLineEdit()
        self.inp_seed.setPlaceholderText("مثلاً: آموزش پرورش اردک در اقلیم گرم")
        form.addRow('عبارت/موضوع مقاله', self.inp_seed)
        v.addLayout(form)

        row = QHBoxLayout()
        self.btn_gen = QPushButton('تولید مقاله + متادیتا')
        self.btn_gen.clicked.connect(self._gen_article)
        self.btn_pub = QPushButton('انتشار در وردپرس کاربر + کسر اعتبار')
        self.btn_pub.clicked.connect(self._publish_article)
        row.addWidget(self.btn_gen)
        row.addWidget(self.btn_pub)
        v.addLayout(row)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        v.addWidget(self.progress)

        self.txt_article = QTextEdit()
        self.txt_article.setAcceptRichText(True)
        v.addWidget(self.txt_article, 3)

        log_box = QGroupBox('گزارش عملیات')
        log_lay = QVBoxLayout(log_box)
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        log_lay.addWidget(self.txt_log)
        v.addWidget(log_box, 1)

    # ------------------ کمک‌ها ------------------
    def _sanitize_query_en(self, s: str) -> str:
        """
        خروجی مجاز برای Pixabay:
        - فقط حروف انگلیسی و فاصله
        - بدون , ; : " ' ( ) … و هر نشانهٔ دیگر
        - ۳ تا ۶ واژه
        - lowercase
        """
        if not s:
            return ""
        # حذف هر کاراکتر غیراز a-z و فاصله
        s = ALLOWED_CHARS_RE.sub(" ", s)
        # استخراج واژه‌ها
        words = WORD_RE.findall(s)
        if not words:
            return ""
        words = words[:6]  # حداکثر ۶
        if len(words) < 3:
            return ""       # کمتر از ۳ واژه معتبر نیست
        return " ".join(w.lower() for w in words)

    def _ensure_image_query_en(self, seed: str, meta_img: str, api_key: str) -> str:
        """
        1) تلاش با مقدار متادیتا + پاک‌سازی
        2) اگر نامعتبر شد، «فقط عبارت انگلیسی» را از جمینی می‌خواهیم (خروجی صرفاً 3–6 کلمه، بدون هیچ علامت/کوتیشن)
        3) اگر باز هم نامعتبر بود → خطا (تصویر ساخته نمی‌شود؛ طبق خواستهٔ شما راه‌حل‌های غیرمعمول استفاده نمی‌کنیم)
        """
        q = self._sanitize_query_en(meta_img)
        if q:
            return q

        self.sigLog.emit("ℹ️ image_query_en نامعتبر بود؛ درخواست بازتولیدِ «عبارت انگلیسی تصویر» از Gemini...")
        try:
            prompt = (
                "Return ONLY 3 to 6 plain English words for an image search about this topic.\n"
                "Constraints:\n"
                "- Allowed characters: letters a–z and spaces only\n"
                "- Lowercase\n"
                "- No punctuation, no quotes, no numbers, no extra text\n"
                "Output must be words only (e.g., fresh vegetable farming)\n\n"
                f"TOPIC: {seed}"
            )
            raw = generate_article(seed, api_key, prompt)
            q = self._sanitize_query_en(raw)
            if q:
                return q
        except Exception as e:
            self.sigLog.emit("⚠️ خطا در بازتولید عبارت انگلیسی: " + str(e))

        # طبق نکتهٔ شما، راه‌حل‌های غیرمعمول (تبدیل seed/… به انگلیسی) اعمال نمی‌کنیم
        raise ValueError("عبارت انگلیسی معتبر برای جستجوی تصویر تولید نشد.")

    # ------------------ اسلات‌های UI ------------------
    @Slot(str)
    def _append_log(self, s: str):
        self.txt_log.append(s)

    @Slot(str)
    def _on_article(self, html: str):
        self.txt_article.setHtml(html if html.strip().startswith('<') else f"<article>{html}</article>")

    @Slot(int)
    def _on_progress(self, val: int):
        self.progress.setValue(max(0, min(100, val)))

    @Slot(str, str)
    def _on_info(self, title: str, body: str):
        QMessageBox.information(self, title, body)

    @Slot(str, str)
    def _on_warn(self, title: str, body: str):
        QMessageBox.warning(self, title, body)

    @Slot(str, str)
    def _on_error(self, title: str, body: str):
        QMessageBox.critical(self, title, body)

    @Slot(bool, bool)
    def _set_publish_enabled(self, enabled: bool, success_lock: bool = False):
        self._publishing = not enabled
        self.btn_pub.setEnabled(bool(enabled))
        self.btn_pub.setStyleSheet("opacity: 1.0;" if enabled else "opacity: 0.5;")

    # ------------------ پاک‌سازی HTML ------------------
    def _clean_html_before_publish(self, html: str) -> str:
        s = (html or "").strip()
        s = re.sub(r"<!DOCTYPE[^>]*>", "", s, flags=re.I)
        s = re.sub(r"<\?xml[^>]*\?>", "", s, flags=re.I)
        s = re.sub(r"<meta[^>]*qrichtext[^>]*>", "", s, flags=re.I)
        s = re.sub(r"<style[^>]*>.*?</style>", "", s, flags=re.S | re.I)
        m = re.search(r"<body[^>]*>(.*?)</body>", s, flags=re.S | re.I)
        if m: s = m.group(1)
        s = re.sub(r'\sstyle="[^"]*"', "", s, flags=re.I)
        s = re.sub(r"</?(html|head)\b[^>]*>", "", s, flags=re.I)
        s = s.strip()
        if not re.search(r"<\s*article\b", s, flags=re.I):
            s = f"<article>{s}</article>"
        return s

    # ------------------ پارس JSON مقاوم ------------------
    def _extract_json_obj(self, text: str) -> dict | None:
        if not text:
            return None
        raw = text.strip()
        self.sigLog.emit("📦 RAW META TEXT:\n" + raw)

        # حذف fence
        raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
        raw = re.sub(r"\s*```$", "", raw)
        # نرمال‌سازی کوتیشن‌ها + حذف comma اضافه
        raw = (raw
               .replace("\u201c", '"').replace("\u201d", '"').replace("\u201e", '"')
               .replace("\u2018", "'").replace("\u2019", "'")
               .replace("\u00ab", '"').replace("\u00bb", '"'))
        raw = re.sub(r",(\s*[}\])", r"\1", raw)

        # تلاش‌های مرحله‌ای
        try:
            obj = json.loads(raw)
            if isinstance(obj, dict): return obj
        except Exception: pass

        i, j = raw.find("{"), raw.rfind("}")
        if i != -1 and j != -1 and j > i:
            try:
                obj = json.loads(raw[i:j+1])
                if isinstance(obj, dict): return obj
            except Exception: pass

        # literal_eval
        pyish = re.sub(r"\btrue\b", "True", raw, flags=re.I)
        pyish = re.sub(r"\bfalse\b", "False", pyish, flags=re.I)
        pyish = re.sub(r"\bnull\b", "None", pyish, flags=re.I)
        try:
            obj = ast.literal_eval(pyish)
            if isinstance(obj, dict): return obj
        except Exception: pass

        # fallback حداقلی
        def _grab(key: str, s: str) -> str:
            m = re.search(r'["\']' + re.escape(key) + r'["\']\s*:\s*["\'](.*?)["\']', s, flags=re.S)
            return m.group(1).strip() if m else ""
        res = {
            "title": _grab("title", raw),
            "long_tail_keyword": _grab("long_tail_keyword", raw),
            "image_query_en": _grab("image_query_en", raw),
            "meta_description": _grab("meta_description", raw),
        }
        if any(res.values()):
            return res
        return None

    # ------------------ تولید مقاله + متادیتا ------------------
    def _gen_article(self):
        seed = self.inp_seed.text().strip()
        if not seed:
            self.sigWarn.emit('خطا', 'عبارت/موضوع مقاله را وارد کنید.')
            return

        api_key = self.state.get('gemini_api_key', '').strip()
        if not api_key:
            self.sigWarn.emit('خطا', 'کلید Gemini تنظیم نشده است. از تب تنظیمات وارد کنید.')
            return

        self.sigProgress.emit(3)

        def work():
            # فاز مقاله
            try:
                self.sigLog.emit('✍️ در حال تولید مقاله‌ی HTML...')
                prompt_article = (
                    "فقط و فقط HTML معتبر خروجی بده و هیچ متن دیگری ننویس. "
                    "کل محتوا داخل تگ <article> باشد؛ بدون <style> و بدون استایل inline. "
                    "حداقل 1200 کلمه، H2/H3 منظم، پاراگراف‌بندی مناسب.\n\n"
                    f"موضوع: «{seed}»"
                )
                html = generate_article(seed, api_key, prompt_article)
                self.sigArticleReady.emit(html)
                self.sigProgress.emit(55)
                self.sigLog.emit('✅ مقاله تولید شد.')
            except Exception as e:
                self.sigLog.emit('❌ ARTICLE ERROR: ' + repr(e))
                self.sigProgress.emit(0)
                self.sigError.emit('خطا', str(e))
                return

            # فاز متادیتا
            meta = {}
            try:
                self.sigLog.emit('🧩 در حال تولید JSON متادیتا...')
                prompt_meta = (
                    "Return ONLY a raw JSON object with EXACTLY these keys (no markdown, no code fences, no extra text):\n"
                    '{'\
                    '"title": "عنوان فارسی کوتاه و جذاب (<=65 کاراکتر)",'\
                    '"long_tail_keyword": "عبارت دم‌بلند فارسی 3–5 واژه قابل جستجو",'\
                    '"image_query_en": "3–6 English words for image search (letters a–z and spaces only; lowercase; no punctuation)",'\
                    '"meta_description": "متادسکریپشن فارسی 140–160 کاراکتر"'\
                    '}\n'
                    f"Use this TOPIC as context (do not echo it verbatim if unnatural): {seed}"
                )
                meta_text = generate_article(seed, api_key, prompt_meta)
                meta = self._extract_json_obj(meta_text) or {}
            except Exception as e:
                self.sigLog.emit('❌ META ERROR: ' + repr(e))
                meta = {}

            # نهایی‌سازی متادیتا (بدون KeyError)
            meta_title = (isinstance(meta, dict) and meta.get("title")) or seed
            meta_kw    = (isinstance(meta, dict) and meta.get("long_tail_keyword")) or seed
            meta_img   = (isinstance(meta, dict) and meta.get("image_query_en")) or ""
            meta_desc  = (isinstance(meta, dict) and meta.get("meta_description")) or ""

            # الزام: image_query_en باید معتبر و مناسب Pixabay باشد
            try:
                meta_img = self._ensure_image_query_en(seed, meta_img, api_key)
            except Exception as e:
                self.sigProgress.emit(0)
                self.sigLog.emit('❌ ' + str(e))
                self.sigError.emit('خطا', 'عبارت انگلیسی معتبر برای جستجوی تصویر تولید نشد. لطفاً دوباره تولید را بزنید.')
                return

            self._article_meta = {
                "title": str(meta_title).strip(),
                "long_tail_keyword": str(meta_kw).strip(),
                "image_query_en": str(meta_img).strip(),
                "meta_description": str(meta_desc).strip(),
            }
            self.sigLog.emit(f'🧾 متادیتا: title="{self._article_meta["title"]}" | kw="{self._article_meta["long_tail_keyword"]}" | img="{self._article_meta["image_query_en"]}"')
            self.sigProgress.emit(100)
            self.sigInfo.emit('موفق', 'مقاله و متادیتا تولید شد.')

        threading.Thread(target=work, daemon=True).start()

    # ------------------ ریست فرم ------------------
    @Slot()
    def _reset_after_success(self):
        try:
            self.inp_seed.clear()
            self.txt_article.clear()
            self.progress.setValue(0)
            self._article_meta = {}
            self._set_publish_enabled(True)
        except Exception:
            pass

    # ------------------ انتشار به وردپرس ------------------
    def _publish_article(self):
        if self._publishing:
            return
        self._set_publish_enabled(False)

        seed = self.inp_seed.text().strip()
        raw_html = self.txt_article.toHtml()
        if not raw_html.strip():
            self.sigWarn.emit('خطا', 'محتوایی برای انتشار وجود ندارد.')
            self.sigPublishEnable.emit(True, False)
            return

        html_clean = self._clean_html_before_publish(raw_html)

        meta = self._article_meta or {}
        wp_title = (isinstance(meta, dict) and meta.get("title")) or seed or "بدون عنوان"
        focus_kw = (isinstance(meta, dict) and meta.get("long_tail_keyword")) or seed
        image_en = (isinstance(meta, dict) and meta.get("image_query_en")) or ""
        meta_desc = (isinstance(meta, dict) and meta.get("meta_description")) or ""

        # اطمینان دوباره از معتبر بودن عبارت انگلیسی
        api_key = self.state.get('gemini_api_key', '').strip()
        try:
            image_en = self._ensure_image_query_en(seed, image_en, api_key)
        except Exception as e:
            self.sigLog.emit('❌ ' + str(e))
            self.sigError.emit('خطا', 'عبارت انگلیسی معتبر برای تصویر تولید نشد. انتشار متوقف شد.')
            self.sigPublishEnable.emit(True, False)
            return

        # پیکربندی وردپرس
        wp_cfg = self.state.get('wp_target') or {}
        site = (wp_cfg.get('url') or '').strip()
        user = (wp_cfg.get('username') or '').strip()
        app  = (wp_cfg.get('app_password') or '').strip()
        seo  = (wp_cfg.get('seo_plugin') or 'none').strip()
        if not (site and user and app):
            self.sigWarn.emit('خطا', 'اتصال وردپرس در تنظیمات کامل نشده است.')
            self.sigPublishEnable.emit(True, False)
            return
        wp = UserWP(site, user, app, seo_plugin=seo)

        # واترمارک از دامنهٔ سایت کاربر
        wm_text = ''
        if URL_RE.search(site):
            try:
                wm_text = urlparse(site).netloc
            except Exception:
                wm_text = ''

        brand = self.state.get('branding') or {}
        logo_path = (brand.get('logo_path') or '').strip()
        font_path = (brand.get('font_path') or '').strip()

        pixabay_key = (self.state.get('pixabay_api_key') or '').strip()
        if not pixabay_key:
            self.sigWarn.emit('خطا', 'Pixabay API Key تنظیم نشده است (تب تنظیمات).')
            self.sigPublishEnable.emit(True, False)
            return

        # ساخت تصویر (اکنون image_en پاک‌سازی‌شده و فقط a–z + space است)
        self.sigLog.emit(f'🖼️ در حال ساخت تصویر شاخص با جستجو: {image_en}')
        try:
            out_path = compose_feature_image(
                pixabay_api_key=pixabay_key,
                search_query_en=image_en,
                title_fa=wp_title,
                logo_path=logo_path,
                site_watermark=wm_text,
                output_dir=os.getcwd(),
                font_path=font_path,
                log=self.sigLog.emit,
            )
        except Exception as e:
            self.sigLog.emit('خطا در ساخت تصویر: ' + str(e))
            self.sigError.emit('تصویر', str(e))
            self.sigPublishEnable.emit(True, False)
            return

        self.sigProgress.emit(35)
        self.sigLog.emit('⬆️ در حال آپلود تصویر به وردپرس...')
        alt_text = wp_title

        def work():
            try:
                media_id = upload_media(site, user, app, out_path, alt_text=alt_text)
            except Exception as e:
                self.sigLog.emit('⚠️ خطا در آپلود تصویر: ' + str(e))
                self.sigError.emit('آپلود تصویر', str(e))
                self.sigPublishEnable.emit(True, False)
                return

            self.sigLog.emit('📰 در حال انتشار پست در وردپرس...')
            self.sigProgress.emit(60)
            try:
                j = None
                try:
                    j = wp.create_post(
                        wp_title, html_clean, status='draft',
                        focus_keyword=focus_kw, meta_desc=meta_desc, featured_media=media_id
                    )
                except TypeError:
                    j = wp.create_post(
                        wp_title, html_clean, status='draft',
                        focus_keyword=focus_kw, meta_desc=meta_desc
                    )
                post_id = (j or {}).get('id') if isinstance(j, dict) else None

                if post_id and media_id:
                    try:
                        set_featured_image(site, user, app, int(post_id), int(media_id))
                    except Exception as e:
                        self.sigLog.emit('هشدار ثبت Featured Image: ' + str(e))

                # کسر اعتبار
                new_display = credits_consume(self.state, 1)
                self.sigCreditsChanged.emit(int(new_display))
                self.sigLog.emit(f'اعتبار باقی‌مانده (نمایشی): {new_display}')

                self.sigProgress.emit(100)
                self.sigLog.emit(f'✅ پست ایجاد شد (ID={post_id})')
                self.sigInfo.emit('موفق', 'پست با موفقیت ایجاد شد.')
                self.sigResetAfterSuccess.emit()
            except Exception as e:
                self.sigProgress.emit(0)
                self.sigLog.emit('خطا در انتشار: ' + str(e))
                self.sigError.emit('خطا', str(e))
                self.sigPublishEnable.emit(True, False)

        threading.Thread(target=work, daemon=True).start()
