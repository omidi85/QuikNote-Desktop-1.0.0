# -*- coding: utf-8 -*-
"""
CentralAPI — گِیت احراز هویت فقط در ورود (یک‌بار و تمام):
- base_url هرچه باشد به .../wp-json/quiknote/v1 نرمالایز می‌شود.
- فقط «اولین بار» که می‌خواهیم دادهٔ حساس بگیریم، قبلش /auth/check با HWID صدا می‌زنیم.
- برای /auth/check اگر سرور WP_Error بدهد (code/message)، همان JSON را برمی‌گردانیم
  تا UI پیام فارسی مناسب نشان بدهد. سایر مسیرها رفتار استاندارد Exception دارند.
"""

from __future__ import annotations
from typing import Any, Dict
import requests, json

API_PREFIX = "/wp-json/quiknote/v1"

def _normalize_base(u: str) -> str:
    u = (u or "").strip().rstrip("/")
    if u.endswith(API_PREFIX):
        return u
    if "/wp-json/quiknote/v1" in u:
        return u[:u.index("/wp-json/quiknote/v1")] + API_PREFIX
    if "/wp-json" in u:
        return u[:u.index("/wp-json")] + API_PREFIX
    return u + API_PREFIX

def _safe_json(obj: Any) -> str:
    try:
        return json.dumps(obj, ensure_ascii=False)
    except Exception:
        return str(obj)

class CentralAPI:
    def __init__(self, base_url: str, email: str, password: str, timeout: int = 15) -> None:
        self.base = _normalize_base(base_url)
        print("DEBUG BASE URL:", self.base)

        self.email = email or ""
        self.password = password or ""
        self.timeout = int(timeout) if timeout else 15
        self.sess = requests.Session()
        self._login_verified = False  # ← بعد از یک ورود موفق True می‌شود

    # ---------- پایین‌دستی: ارسال ----------
    def _post(self, path: str, payload: Dict[str, Any]) -> Any:
        if not path.startswith("/"):
            path = "/" + path
        url = self.base + path

        body: Dict[str, Any] = {"email": self.email, "password": self.password}
        if payload:
            body.update(payload)

        r = self.sess.post(url, json=body, timeout=self.timeout)

        # تلاش برای JSON
        try:
            j = r.json()
        except ValueError:
            j = None

        # هندل خطا
        if r.status_code >= 400:
            if isinstance(j, dict) and "code" in j and "message" in j:
                # فقط برای ورود: JSON خطا را به UI بده (تا پیام فارسی نمایش دهد)
                if path == "/auth/check":
                    return j
                raise RuntimeError(f"{j.get('code')}: {j.get('message')}")
            # HTML/متن خام
            txt = (r.text or "").strip()
            raise RuntimeError(f"HTTP {r.status_code} @ {url}\n{txt[:500]}")

        # موفقیت
        if j is not None:
            return j
        return r.text

    # ---------- گِیت یک‌بارهٔ ورود ----------
    def _ensure_login_once(self) -> None:
        """اگر تا حالا ورود تأیید نشده، یکبار /auth/check با HWID بزن و نتیجه را قفل کن."""
        if self._login_verified:
            return

        # HWID را فقط همینجا می‌فرستیم (سیاست شما: چک فقط در ورود)
        try:
            from quiknote.hwid import current_hwid_hex
            hwid = current_hwid_hex()
        except Exception:
            hwid = ""

        resp = self.auth_check(hwid=hwid)
        # اگر سرور WP_Error JSON داد، آن را به Exception تبدیل کنیم تا UI پیام درست نشان دهد
        if isinstance(resp, dict) and resp.get("code"):
            # مثال: no_hwid / bad_hwid / hwid_taken / bad_creds
            raise RuntimeError(str(resp.get("message") or resp.get("code")))
        if not (isinstance(resp, dict) and resp.get("status") == "ok"):
            raise RuntimeError("احراز هویت HWID ناموفق بود.")
        self._login_verified = True

    # ---------- اندپوینت‌ها ----------
    def auth_check(self, hwid: str = "") -> Any:
        pl: Dict[str, Any] = {}
        if hwid:
            pl["hwid"] = hwid
        return self._post("/auth/check", pl)

    def profile(self) -> Any:
        self._ensure_login_once()      # ← فقط همینجا یکبار گِیت می‌کنیم
        return self._post("/profile", {})

    def credits_get(self) -> Any:
        self._ensure_login_once()      # ← و اینجا
        return self._post("/credits", {})

    def support(self) -> Any:
        self._ensure_login_once()      # ← مسیرهای حساس دیگر همون اول گِیت می‌شوند
        return self._post("/support", {})

    def referral(self) -> Any:
        self._ensure_login_once()
        return self._post("/referral", {})
