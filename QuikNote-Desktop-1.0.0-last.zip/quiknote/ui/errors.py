from typing import Dict

def localized_error_message(code: str, fallback_message: str = "") -> str:
    code = (code or "").strip()
    MESSAGES: Dict[str, str] = {
        "no_hwid":   "برای ورود لازم است کد سخت‌افزاری این دستگاه ارسال شود. لطفاً برنامه را به‌روز کنید یا دوباره تلاش کنید.",
        "bad_hwid":  "کد سخت‌افزاری دستگاه نامعتبر است. لطفاً برنامه را بسته و دوباره باز کنید.",
        "hwid_taken":"این دستگاه قبلاً ثبت شده است و نمی‌توانید با همین سیستم وارد حساب دیگری شوید.",
        "bad_creds": "ایمیل یا رمز عبور اشتباه است.",
        "no_creds":  "ایمیل/رمز عبور لازم است.",
    }
    return MESSAGES.get(code, fallback_message or "در انجام عملیات مشکلی رخ داد. لطفاً دوباره تلاش کنید.")
