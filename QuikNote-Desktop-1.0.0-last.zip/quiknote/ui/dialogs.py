from PySide6.QtWidgets import QMessageBox, QWidget

def show_error_dialog(parent: QWidget, title: str, text: str):
    m = QMessageBox(parent)
    m.setIcon(QMessageBox.Critical)
    m.setWindowTitle(title)
    m.setText(text)
    m.setStandardButtons(QMessageBox.Ok)
    m.exec()
