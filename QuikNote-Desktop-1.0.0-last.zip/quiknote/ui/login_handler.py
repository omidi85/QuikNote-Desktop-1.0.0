# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import Optional, Any
from PySide6.QtWidgets import QWidget
from quiknote.api import CentralAPI
from quiknote.hwid import current_hwid_hex
from quiknote.ui.errors import localized_error_message
from quiknote.ui.dialogs import show_error_dialog

def _extract_wp_error(resp: Any):
    if isinstance(resp, dict) and 'code' in resp and 'message' in resp:
        return resp.get('code'), resp.get('message')
    return None

def attempt_login(parent: Optional[QWidget], api: CentralAPI) -> bool:
    hwid = current_hwid_hex()
    try:
        resp = api.auth_check(hwid=hwid)
    except Exception as e:
        show_error_dialog(parent, 'خطا', str(e))
        return False
    wp_err = _extract_wp_error(resp)
    if wp_err:
        code, message = wp_err
        show_error_dialog(parent, 'ورود ناموفق', localized_error_message(code, message))
        return False
    if isinstance(resp, dict) and resp.get('status') == 'ok':
        return True
    show_error_dialog(parent, 'خطا', 'پاسخ غیرمنتظره از سرور دریافت شد.')
    return False
