# -*- coding: utf-8 -*-
from __future__ import annotations
from PySide6.QtCore import QObject, Slot
from PySide6.QtWidgets import QLabel
from ..credits import get as credits_get

class CreditsController(QObject):
    def __init__(self, state: dict, label: QLabel, parent=None):
        super().__init__(parent)
        self.state = state
        self.label = label
        self.refresh()

    @Slot(int)
    def on_changed(self, val: int):
        # val همان get(state) است که از تب‌ها سیگنال می‌آید
        self.label.setText(str(val))

    def refresh(self):
        self.label.setText(str(credits_get(self.state)))
